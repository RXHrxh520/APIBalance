package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 * ... (AGPLv3, see MainActivity)
 */

import android.app.Fragment;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.Executor;

public class LockFragment extends Fragment {

    private EditText etPassword;
    private TextView tvUnlock;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_lock, container, false);

        etPassword = view.findViewById(R.id.et_password);
        tvUnlock = view.findViewById(R.id.btn_unlock);

        // 优先尝试指纹
        tryBiometric();

        tvUnlock.setOnClickListener(v -> {
            String pw = etPassword.getText().toString().trim();
            String saved = PrivacyPrefs.getPassword(getActivity());
            if (saved == null) {
                // 首次设置密码
                if (pw.length() < 4) {
                    Toast.makeText(getActivity(), "请设置至少 4 位密码", Toast.LENGTH_SHORT).show();
                    return;
                }
                PrivacyPrefs.setPassword(getActivity(), pw);
                Toast.makeText(getActivity(), "密码已设置", Toast.LENGTH_SHORT).show();
                unlock();
            } else {
                if (saved.equals(pw)) {
                    unlock();
                } else {
                    Toast.makeText(getActivity(), "密码错误", Toast.LENGTH_SHORT).show();
                    etPassword.setText("");
                }
            }
        });

        return view;
    }

    private void tryBiometric() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return;
        final android.app.Activity act = getActivity();
        if (act == null) return;
        android.hardware.fingerprint.FingerprintManager fm =
                act.getSystemService(android.hardware.fingerprint.FingerprintManager.class);
        if (fm == null || !fm.isHardwareDetected() || !fm.hasEnrolledFingerprints()) {
            // 无指纹硬件/未录入指纹，提示用密码
            Toast.makeText(act, "未检测到指纹，请使用密码解锁", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!fm.isHardwareDetected()) return;
        android.hardware.fingerprint.FingerprintManager.AuthenticationCallback cb =
                new android.hardware.fingerprint.FingerprintManager.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(android.hardware.fingerprint.FingerprintManager.AuthenticationResult result) {
                        if (getActivity() != null) {
                            getActivity().runOnUiThread(() -> unlock());
                        }
                    }
                };
        fm.authenticate(null, null, 0, cb, null);
    }

    private void unlock() {
        MainActivity act = (MainActivity) getActivity();
        if (act != null) act.onLockPassed();
    }
}