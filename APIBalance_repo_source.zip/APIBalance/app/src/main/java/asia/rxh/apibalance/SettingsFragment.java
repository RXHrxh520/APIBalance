package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 * ... (AGPLv3, see MainActivity)
 */

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

public class SettingsFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        ImageView btnBack = view.findViewById(R.id.btn_back);
        View btnChangeKey = view.findViewById(R.id.btn_change_key);
        View btnSwitchProvider = view.findViewById(R.id.btn_switch_provider);
        View btnAccounts = view.findViewById(R.id.btn_accounts);
        View btnHistory = view.findViewById(R.id.btn_history);
        View btnTheme = view.findViewById(R.id.btn_theme);
        View btnTimeout = view.findViewById(R.id.btn_timeout);
        View btnCurrency = view.findViewById(R.id.btn_currency);
        View btnClearData = view.findViewById(R.id.btn_clear_data);
        View btnTokenEst = view.findViewById(R.id.btn_token_est);
        View btnAdvancedNet = view.findViewById(R.id.btn_advanced_net);
        View btnFontSize = view.findViewById(R.id.btn_font_size);
        View btnCustomBg = view.findViewById(R.id.btn_custom_bg);
        TextView tvFontSize = view.findViewById(R.id.tv_font_size);
        TextView tvBgDesc = view.findViewById(R.id.tv_bg_desc);
        View btnProxy = view.findViewById(R.id.btn_proxy);
        Switch swProxy = view.findViewById(R.id.sw_proxy);
        TextView tvProxyDesc = view.findViewById(R.id.tv_proxy_desc);
        TextView tvTimeoutDesc = view.findViewById(R.id.tv_timeout_desc);
        TextView tvCurrencyDesc = view.findViewById(R.id.tv_currency_desc);
        Switch swLock = view.findViewById(R.id.sw_lock);
        Switch swHideBalance = view.findViewById(R.id.sw_hide_balance);
        Switch swNoScreenshot = view.findViewById(R.id.sw_no_screenshot);
        Switch swNoNotify = view.findViewById(R.id.sw_no_notify);
        Switch swFloat = view.findViewById(R.id.sw_float);
        View rowFloat = view.findViewById(R.id.row_float);
        Switch swAlert = view.findViewById(R.id.sw_alert);
        Switch swAutoRefresh = view.findViewById(R.id.sw_auto_refresh);
        Switch swQuiet = view.findViewById(R.id.sw_quiet);
        Switch swSticky = view.findViewById(R.id.sw_sticky);
        TextView tvQuietDesc = view.findViewById(R.id.tv_quiet_desc);
        View rowQuiet = view.findViewById(R.id.row_quiet);
        View rowSticky = view.findViewById(R.id.row_sticky);
        TextView tvAlertDesc = view.findViewById(R.id.tv_alert_desc);
        View rowAlert = view.findViewById(R.id.row_alert);
        View rowAutoRefresh = view.findViewById(R.id.row_auto_refresh);
        View rowLock = view.findViewById(R.id.row_lock);
        View rowHideBalance = view.findViewById(R.id.row_hide_balance);
        View rowNoScreenshot = view.findViewById(R.id.row_no_screenshot);
        View rowNoNotify = view.findViewById(R.id.row_no_notify);
        TextView tvThemeMode = view.findViewById(R.id.tv_theme_mode);
        View btnThemeColor = view.findViewById(R.id.btn_theme_color);
        TextView tvThemeColor = view.findViewById(R.id.tv_theme_color);
        View btnAbout = view.findViewById(R.id.btn_about);
        View btnUpdate = view.findViewById(R.id.btn_update);
        View btnDebug = view.findViewById(R.id.btn_debug);
        TextView tvCurrentProvider = view.findViewById(R.id.tv_current_provider);

        MainActivity activity = (MainActivity) getActivity();
        if (activity != null) {
            if (activity.isDebugEnabled()) {
                btnDebug.setVisibility(View.VISIBLE);
            }
            if (tvCurrentProvider != null) {
                tvCurrentProvider.setText("当前：" + ProviderConfig.get(activity.getCurrentProviderId()).name);
            }
            if (tvTimeoutDesc != null) {
                tvTimeoutDesc.setText("超时 " + AppPrefs.getTimeoutSec(getActivity()) + "s · 重试 " + AppPrefs.getRetryCount(getActivity()) + " 次");
            }
            if (tvCurrencyDesc != null) {
                int cm = AppPrefs.getDisplayCurrency(getActivity());
                tvCurrencyDesc.setText(cm == 1 ? "CNY" : cm == 2 ? "USD" : "自动识别");
            }
        }

        btnBack.setOnClickListener(v -> {
            if (getActivity() != null) {
                getFragmentManager().popBackStack();
            }
        });

        // 提醒/刷新
        if (swAlert != null) {
            swAlert.setChecked(AppPrefs.isAlertEnabled(getActivity()));
            swAlert.setOnCheckedChangeListener((b, isChecked) -> AppPrefs.setAlertEnabled(getActivity(), isChecked));
            if (rowAlert != null) {
                rowAlert.setOnClickListener(v -> {
                    MainActivity act = (MainActivity) getActivity();
                    if (act == null) return;
                    final String[] opts = {"5", "10", "20", "50", "100"};
                    int sel = 1;
                    double cur = AppPrefs.getAlertThreshold(act);
                    for (int i = 0; i < opts.length; i++) {
                        if ((int) cur == Integer.parseInt(opts[i])) { sel = i; break; }
                    }
                    UiDialog.showPicker(act, "提醒阈值", opts, sel, w -> {
                        AppPrefs.setAlertThreshold(act, Integer.parseInt(opts[w]));
                        if (tvAlertDesc != null) tvAlertDesc.setText("低于阈值时通知 · 阈值 " + opts[w]);
                    });
                });
            }
        }
        if (swAutoRefresh != null) {
            swAutoRefresh.setChecked(AppPrefs.isAutoRefresh(getActivity()));
            swAutoRefresh.setOnCheckedChangeListener((b, isChecked) -> {
                AppPrefs.setAutoRefresh(getActivity(), isChecked);
                MainActivity act = (MainActivity) getActivity();
                if (act != null) act.scheduleAutoRefresh(isChecked);
            });
        }

        // 通知增强
        if (swQuiet != null) {
            swQuiet.setChecked(AppPrefs.isQuietEnabled(getActivity()));
            if (tvQuietDesc != null) {
                tvQuietDesc.setText(AppPrefs.getQuietStart(getActivity()) + ":00 - "
                        + AppPrefs.getQuietEnd(getActivity()) + ":00 不响铃");
            }
            swQuiet.setOnCheckedChangeListener((b, isChecked) -> AppPrefs.setQuietEnabled(getActivity(), isChecked));
            if (rowQuiet != null) {
                rowQuiet.setOnClickListener(v -> {
                    MainActivity act = (MainActivity) getActivity();
                    if (act == null) return;
                    String[] hours = new String[24];
                    for (int i = 0; i < 24; i++) hours[i] = i + ":00";
                    UiDialog.showPicker(act, "静音开始", hours, AppPrefs.getQuietStart(act), s -> {
                        AppPrefs.setQuietStart(act, s);
                        UiDialog.showPicker(act, "静音结束", hours, AppPrefs.getQuietEnd(act), e -> {
                            AppPrefs.setQuietEnd(act, e);
                            if (tvQuietDesc != null) {
                                tvQuietDesc.setText(s + ":00 - " + e + ":00 不响铃");
                            }
                        });
                    });
                });
            }
        }
        if (swSticky != null) {
            swSticky.setChecked(AppPrefs.isStickyNotify(getActivity()));
            swSticky.setOnCheckedChangeListener((b, isChecked) -> {
                AppPrefs.setStickyNotify(getActivity(), isChecked);
                MainActivity act = (MainActivity) getActivity();
                if (act != null) {
                    if (isChecked) act.showStickyNotify();
                    else Notifier.cancelSticky(act);
                }
            });
        }

        // 桌面悬浮球
        if (swFloat != null) {
            swFloat.setChecked(AppPrefs.isFloatWin(getActivity()));
            swFloat.setOnCheckedChangeListener((b, isChecked) -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                if (isChecked) {
                    if (android.os.Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.canDrawOverlays(act)) {
                        UiDialog.showConfirm(act, "悬浮窗权限",
                                "需要授予【显示在其他应用上层】权限才能开启悬浮球。",
                                "去授权", "取消",
                                () -> {
                                    try {
                                        act.startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                                android.net.Uri.parse("package:" + act.getPackageName())));
                                    } catch (Exception ignored) {
                                    }
                                }, () -> swFloat.setChecked(false));
                    } else {
                        act.startService(new Intent(act, FloatingWindowService.class));
                    }
                } else {
                    act.stopService(new Intent(act, FloatingWindowService.class));
                }
                AppPrefs.setFloatWin(act, isChecked);
            });
        }

        // 隐私开关
        if (swLock != null) {
            swLock.setChecked(PrivacyPrefs.isLockEnabled(getActivity()));
            swLock.setOnCheckedChangeListener((b, isChecked) -> PrivacyPrefs.setLockEnabled(getActivity(), isChecked));
        }
        if (swHideBalance != null) {
            swHideBalance.setChecked(PrivacyPrefs.isHideBalance(getActivity()));
            swHideBalance.setOnCheckedChangeListener((b, isChecked) -> PrivacyPrefs.setHideBalance(getActivity(), isChecked));
        }
        if (swNoScreenshot != null) {
            swNoScreenshot.setChecked(AppPrefs.noScreenshot(getActivity()));
            swNoScreenshot.setOnCheckedChangeListener((b, isChecked) -> {
                AppPrefs.setNoScreenshot(getActivity(), isChecked);
                MainActivity act = (MainActivity) getActivity();
                if (act != null) act.applyPrivacyFlags();
            });
        }
        if (swNoNotify != null) {
            swNoNotify.setChecked(AppPrefs.noNotify(getActivity()));
            swNoNotify.setOnCheckedChangeListener((b, isChecked) -> AppPrefs.setNoNotify(getActivity(), isChecked));
        }

        if (btnThemeColor != null && tvThemeColor != null) {
            int style0 = ThemePrefs.getStyle(getActivity());
            int col0 = ThemePrefs.getColorIndex(getActivity());
            tvThemeColor.setText(ThemePrefs.STYLE_NAMES[style0 % ThemePrefs.STYLE_NAMES.length]
                    + " · " + ThemePrefs.COLOR_NAMES[col0 % ThemePrefs.COLOR_NAMES.length]);
            btnThemeColor.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                // 第一步：选主题风格
                UiDialog.showPicker(act, "主题风格", ThemePrefs.STYLE_NAMES, ThemePrefs.getStyle(act), s -> {
                    ThemePrefs.setStyle(act, s);
                    // 第二步：随心选色
                    UiDialog.showPicker(act, "随心选色", ThemePrefs.COLOR_NAMES, ThemePrefs.getColorIndex(act), w -> {
                        ThemePrefs.setColorIndex(act, w);
                        act.recreate();
                    });
                });
            });
        }

        if (btnTheme != null && tvThemeMode != null) {
            final MainActivity act2 = (MainActivity) getActivity();
            if (act2 != null) {
                int tm = act2.getThemeMode();
                tvThemeMode.setText(tm == 2 ? "深色" : tm == 1 ? "浅色" : "跟随系统");
            }
            btnTheme.setOnClickListener(v -> {
                MainActivity act3 = (MainActivity) getActivity();
                if (act3 == null) return;
                String[] modes = {"跟随系统", "浅色", "深色"};
                UiDialog.showPicker(act3, "主题模式", modes, act3.getThemeMode(), which -> {
                    act3.setThemeMode(which);
                });
            });
        }

        // 超时/重试
        if (btnTimeout != null) {
            btnTimeout.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                final int cur = AppPrefs.getTimeoutSec(act);
                final int curRetry = AppPrefs.getRetryCount(act);
                String[] timeouts = {"10 秒", "15 秒", "30 秒", "60 秒"};
                int sel = cur == 10 ? 0 : cur == 30 ? 2 : cur == 60 ? 3 : 1;
                UiDialog.showPicker(act, "超时时间", timeouts, sel, w -> {
                    int sec = w == 0 ? 10 : w == 2 ? 30 : w == 3 ? 60 : 15;
                    AppPrefs.setTimeoutSec(act, sec);
                    if (tvTimeoutDesc != null)
                        tvTimeoutDesc.setText("超时 " + sec + "s · 重试 " + curRetry + " 次");
                });
            });
        }

        // 多币种
        if (btnCurrency != null) {
            btnCurrency.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                String[] modes = {"自动识别", "CNY", "USD"};
                UiDialog.showPicker(act, "币种显示", modes, AppPrefs.getDisplayCurrency(act), w -> {
                    AppPrefs.setDisplayCurrency(act, w);
                    if (tvCurrencyDesc != null)
                        tvCurrencyDesc.setText(w == 1 ? "CNY" : w == 2 ? "USD" : "自动识别");
                });
            });
        }

        // 网络代理
        if (btnProxy != null && swProxy != null) {
            swProxy.setChecked(AppPrefs.isProxyEnabled(getActivity()));
            if (tvProxyDesc != null) {
                tvProxyDesc.setText((AppPrefs.isProxyEnabled(getActivity()) ? "开启" : "关闭")
                        + " · " + AppPrefs.getProxyHost(getActivity()) + ":" + AppPrefs.getProxyPort(getActivity()));
            }
            swProxy.setOnCheckedChangeListener((b, isChecked) -> {
                AppPrefs.setProxyEnabled(getActivity(), isChecked);
                if (tvProxyDesc != null) {
                    tvProxyDesc.setText((isChecked ? "开启" : "关闭")
                            + " · " + AppPrefs.getProxyHost(getActivity()) + ":" + AppPrefs.getProxyPort(getActivity()));
                }
            });
            btnProxy.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                UiDialog.showInput(act, "代理主机", "如 127.0.0.1", AppPrefs.getProxyHost(act), host -> {
                    AppPrefs.setProxyHost(act, host);
                    UiDialog.showInput(act, "代理端口", "如 7890", String.valueOf(AppPrefs.getProxyPort(act)), portStr -> {
                        try { AppPrefs.setProxyPort(act, Integer.parseInt(portStr)); } catch (Exception ignored) {}
                        if (tvProxyDesc != null) {
                            tvProxyDesc.setText((AppPrefs.isProxyEnabled(act) ? "开启" : "关闭")
                                    + " · " + AppPrefs.getProxyHost(act) + ":" + AppPrefs.getProxyPort(act));
                        }
                    });
                });
            });
        }

        // 字体大小
        if (btnFontSize != null && tvFontSize != null) {
            tvFontSize.setText(AppPrefs.getFontSize(getActivity()) == 0 ? "小"
                    : AppPrefs.getFontSize(getActivity()) == 2 ? "大" : "标准");
            btnFontSize.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                String[] opts = {"小", "标准", "大"};
                UiDialog.showPicker(act, "字体大小", opts, AppPrefs.getFontSize(act), w -> {
                    AppPrefs.setFontSize(act, w);
                    act.recreate();
                });
            });
        }

        // 自定义背景
        if (btnCustomBg != null) {
            btnCustomBg.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                String[] opts = {"选择图片", "清除背景"};
                UiDialog.showPicker(act, "自定义背景", opts, 0, w -> {
                    if (w == 0) {
                        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                        pick.setType("image/*");
                        startActivityForResult(pick, 1001);
                    } else {
                        AppPrefs.setBgPath(act, null);
                        act.recreate();
                    }
                });
            });
        }

        // 高级网络设置
        if (btnAdvancedNet != null) {
            btnAdvancedNet.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                String[] opts = {
                    "TLS 证书校验：" + (AppPrefs.isTlsVerify(act) ? "开启" : "关闭"),
                    "User-Agent：修改",
                    "请求日志：" + (AppPrefs.isReqLog(act) ? "开启" : "关闭"),
                    "刷新间隔：手动设置"
                };
                UiDialog.showPicker(act, "高级网络设置", opts, 0, w -> {
                    switch (w) {
                        case 0:
                            AppPrefs.setTlsVerify(act, !AppPrefs.isTlsVerify(act));
                            break;
                        case 1:
                            UiDialog.showInput(act, "User-Agent", "自定义 UA", AppPrefs.getUserAgent(act),
                                    ua -> AppPrefs.setUserAgent(act, ua));
                            break;
                        case 2:
                            AppPrefs.setReqLog(act, !AppPrefs.isReqLog(act));
                            break;
                        case 3:
                            String[] intervals = {"手动刷新", "1 分钟", "5 分钟", "15 分钟", "30 分钟", "1 小时", "自定义(秒)"};
                            UiDialog.showPicker(act, "刷新间隔", intervals, 0, i2 -> {
                                MainActivity ma = (MainActivity) getActivity();
                                if (i2 == 6) {
                                    // 自定义秒数
                                    UiDialog.showInput(act, "自定义刷新间隔", "输入秒数，如 300",
                                            String.valueOf(AppPrefs.getRefreshIntervalSec(act)), s -> {
                                        try {
                                            int sec = Integer.parseInt(s);
                                            if (sec >= 30) {
                                                AppPrefs.setRefreshIntervalSec(act, sec);
                                                AppPrefs.setAutoRefresh(act, true);
                                                if (ma != null) ma.scheduleAutoRefresh(true);
                                            }
                                        } catch (Exception ignored) {
                                        }
                                    });
                                } else {
                                    int sec = i2 == 1 ? 60 : i2 == 2 ? 300 : i2 == 3 ? 900 : i2 == 4 ? 1800 : i2 == 5 ? 3600 : 0;
                                    AppPrefs.setAutoRefresh(act, i2 > 0);
                                    if (i2 > 0) {
                                        AppPrefs.setRefreshIntervalSec(act, sec);
                                        if (ma != null) ma.scheduleAutoRefresh(true);
                                    }
                                }
                            });
                            break;
                    }
                });
            });
        }

        // Token 估算器
        if (btnTokenEst != null) {
            btnTokenEst.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                UiDialog.showInput(act, "Token 估算器", "粘贴文本，估算 token 数", "", input -> {
                    int tokens = TokenEstimator.estimate(input);
                    UiDialog.showConfirm(act, "估算结果",
                            "文本长度：" + input.length() + " 字符\n\n约 " + tokens + " 个 token",
                            "好", null, null, null);
                });
            });
        }

        // 清除数据
        if (btnClearData != null) {
            btnClearData.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                UiDialog.showConfirm(act, "清除数据",
                        "将清空历史记录、API 密钥与所有设置，确定继续？",
                        "清除", "取消",
                        () -> {
                            BalanceHistoryStore.clear(act);
                            CryptoManager.remove(act, act.getProviderKeyName(act.getCurrentProviderId()));
                            act.getSharedPreferences("ds_balance_prefs", 0).edit().clear().apply();
                            act.getSharedPreferences("ds_settings", 0).edit().clear().apply();
                            act.onChangeKey();
                        }, null);
            });
        }

        if (btnHistory != null) {
            btnHistory.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act != null) act.showHistoryFragment();
            });
        }

        if (btnUpdate != null) {
            btnUpdate.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act != null) UpdateChecker.check(act, true);
            });
        }

        btnAbout.setOnClickListener(v -> {
            MainActivity act = (MainActivity) getActivity();
            if (act != null) act.showAboutFragment();
        });

        btnChangeKey.setOnClickListener(v -> {
            MainActivity act = (MainActivity) getActivity();
            if (act != null) act.onChangeKey();
        });

        // 账户管理
        if (btnAccounts != null) {
            btnAccounts.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                final int pid = act.getCurrentProviderId();
                final java.util.List<AccountManager.Account> accounts =
                        AccountManager.getAccounts(act, pid);
                if (accounts.isEmpty()) {
                    UiDialog.showConfirm(act, "账户管理",
                            "当前服务商暂无已保存账户。\n\n登录成功时会询问是否保存为账户。",
                            "好", null, null, null);
                    return;
                }
                String[] names = new String[accounts.size()];
                for (int i = 0; i < accounts.size(); i++) names[i] = accounts.get(i).name;
                UiDialog.showPicker(act, "选择账户（" + ProviderConfig.get(pid).name + "）",
                        names, 0, w -> {
                            AccountManager.Account acc = accounts.get(w);
                            // 切换到该账户
                            act.onLoginSuccess(acc.key, pid, true);
                        });
            });
        }

        // 切换服务商：清掉当前 key，回登录页重新选择
        if (btnSwitchProvider != null) {
            btnSwitchProvider.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act != null) act.onChangeKey();
            });
        }

        btnDebug.setOnClickListener(v -> {
            MainActivity act = (MainActivity) getActivity();
            if (act != null) act.showDebugFragment();
        });

        // 入场动画：仅在首次进入时播放，避免每次打开设置重复弹跳
        if (savedInstanceState == null) {
            btnChangeKey.setAlpha(0f);
            btnChangeKey.setTranslationY(60f);
            btnChangeKey.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setDuration(400)
                    .setStartDelay(150)
                    .setInterpolator(new OvershootInterpolator(0.6f))
                    .start();

            if (btnSwitchProvider != null) {
                btnSwitchProvider.setAlpha(0f);
                btnSwitchProvider.setTranslationY(60f);
                btnSwitchProvider.animate()
                        .alpha(1f)
                        .translationY(0f)
                        .setDuration(400)
                        .setStartDelay(220)
                        .setInterpolator(new OvershootInterpolator(0.6f))
                        .start();
            }
        }


        // 内容入场动画：淡入 + 上滑
        view.setAlpha(0f);
        view.setTranslationY(24f);
        view.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(420)
                .setInterpolator(android.view.animation.AnimationUtils.loadInterpolator(getActivity(), android.R.interpolator.decelerate_cubic))
                .start();

        return view;
    }
}