package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 *
 * This file is part of APIBalance.
 *
 * APIBalance is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * APIBalance is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/** 检查 GitHub Release 是否有新版本。 */
public final class UpdateChecker {

    private static final String REPO_API = "https://api.github.com/repos/RXHrxh520/APIBalance/releases/latest";
    private static final String REPO_URL = "https://github.com/RXHrxh520/APIBalance";

    private UpdateChecker() {
    }

    public static void check(final Context ctx, final boolean manual) {
        new Thread(() -> {
            int resultCode = 0; // 0=无网络/异常 1=暂无Release 2=有数据
            String version = null;
            String url = null;
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(REPO_API).openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/vnd.github+json");
                conn.setConnectTimeout(12000);
                conn.setReadTimeout(12000);
                int code = conn.getResponseCode();
                if (code == 200) {
                    BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = rd.readLine()) != null) sb.append(line);
                    rd.close();
                    JSONObject obj = new JSONObject(sb.toString());
                    version = obj.optString("tag_name", null);
                    url = obj.optString("html_url", null);
                    resultCode = (version != null) ? 2 : 1;
                } else if (code == 404) {
                    resultCode = 1; // 暂无 Release
                } else {
                    resultCode = 0;
                }
                conn.disconnect();
            } catch (Exception ignored) {
                resultCode = 0;
            }

            final int rc = resultCode;
            final String fv = version;
            final String fu = url;
            final String current = "v" + BuildConfig.VERSION_NAME;
            if (ctx instanceof android.app.Activity) {
                android.app.Activity act = (android.app.Activity) ctx;
                act.runOnUiThread(() -> {
                    if (!manual) return;
                    if (rc == 1) {
                        UiDialog.showConfirm(act, "检查更新",
                                "仓库暂无发布版本。\n\n可以前往仓库查看最新动态。",
                                "打开仓库", "取消",
                                () -> openRepo(act), null);
                    } else if (rc == 0) {
                        UiDialog.showConfirm(act, "检查更新",
                                "无法连接更新服务器，请检查网络后重试。",
                                "重试", "取消",
                                () -> check(ctx, true), null);
                    } else {
                        if (fv.equalsIgnoreCase(current) || fv.replace("v", "").equals(BuildConfig.VERSION_NAME)) {
                            UiDialog.showConfirm(act, "检查更新",
                                    "当前已是最新版本 (" + current + ")",
                                    "好", null, null, null);
                        } else {
                            UiDialog.showConfirm(act, "发现新版本",
                                    "最新版本：" + fv + "\n当前版本：" + current,
                                    "前往下载", "稍后",
                                    () -> openRepo(act, fu), null);
                        }
                    }
                });
            }
        }).start();
    }

    private static void openRepo(android.app.Activity act) {
        openRepo(act, null);
    }

    private static void openRepo(android.app.Activity act, String url) {
        try {
            act.startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse(url != null ? url : REPO_URL)));
        } catch (Exception ignored) {
        }
    }
}
