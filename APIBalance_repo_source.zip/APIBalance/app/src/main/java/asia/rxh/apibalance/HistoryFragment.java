package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 * ... (AGPLv3, see MainActivity)
 */

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HistoryFragment extends Fragment {

    private static final int FILTER_ALL_PROVIDER = -1;
    private static final int FILTER_ALL_TIME = 0;
    private static final int FILTER_7D = 1;
    private static final int FILTER_30D = 2;
    private static final int FILTER_90D = 3;

    private int filterProvider = FILTER_ALL_PROVIDER;
    private int filterTime = FILTER_ALL_TIME;

    private TextView btnFilterProvider;
    private TextView btnFilterTime;
    private TextView tvStats;
    private TrendChartView chart;
    private TextView tvEmpty;
    private LinearLayout historyContainer;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_history, container, false);

        ImageView btnBack = view.findViewById(R.id.btn_back);
        TextView btnClear = view.findViewById(R.id.btn_clear);
        chart = view.findViewById(R.id.trend_chart);
        tvEmpty = view.findViewById(R.id.tv_trend_empty);
        historyContainer = view.findViewById(R.id.history_container);
        btnFilterProvider = view.findViewById(R.id.btn_filter_provider);
        btnFilterTime = view.findViewById(R.id.btn_filter_time);
        tvStats = view.findViewById(R.id.tv_stats);

        btnBack.setOnClickListener(v -> {
            if (getActivity() != null) getFragmentManager().popBackStack();
        });

        btnClear.setOnClickListener(v -> {
            BalanceHistoryStore.clear(getActivity().getApplicationContext());
            refresh();
            Toast.makeText(getActivity(), "历史记录已清空", Toast.LENGTH_SHORT).show();
        });

        // 服务商筛选
        btnFilterProvider.setOnClickListener(v -> {
            String[] options = new String[ProviderConfig.count() + 1];
            options[0] = "全部服务商";
            for (int i = 0; i < ProviderConfig.count(); i++) {
                options[i + 1] = ProviderConfig.get(i).name;
            }
            int sel = filterProvider + 1;
            UiDialog.showPicker(getActivity(), "按服务商筛选", options, sel, w -> {
                filterProvider = w - 1;
                refresh();
            });
        });

        // 时间筛选
        btnFilterTime.setOnClickListener(v -> {
            String[] options = {"全部时间", "近 7 天", "近 30 天", "近 90 天"};
            UiDialog.showPicker(getActivity(), "按时间筛选", options, filterTime, w -> {
                filterTime = w;
                refresh();
            });
        });

        refresh();

        // 内容入场动画
        view.setAlpha(0f);
        view.setTranslationY(24f);
        view.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(420)
                .setInterpolator(android.view.animation.AnimationUtils.loadInterpolator(getActivity(), android.R.interpolator.decelerate_cubic))
                .start();

        return view;
    }

    private void refresh() {
        try {
            List<BalanceHistoryStore.HistoryItem> all =
                    BalanceHistoryStore.getAll(getActivity().getApplicationContext());
            List<BalanceHistoryStore.HistoryItem> items = new ArrayList<>();
            long now = System.currentTimeMillis();
            long limit = 0;
            if (filterTime == FILTER_7D) limit = 7L * 24 * 3600 * 1000;
            else if (filterTime == FILTER_30D) limit = 30L * 24 * 3600 * 1000;
            else if (filterTime == FILTER_90D) limit = 90L * 24 * 3600 * 1000;

            for (BalanceHistoryStore.HistoryItem it : all) {
                if (filterProvider != FILTER_ALL_PROVIDER && it.providerId != filterProvider) continue;
                if (limit > 0 && now - it.ts > limit) continue;
                items.add(it);
            }

            // 筛选按钮样式
            btnFilterProvider.setText(filterProvider == FILTER_ALL_PROVIDER ? "全部服务商"
                    : ProviderConfig.get(filterProvider).name);
            btnFilterTime.setText(filterTime == FILTER_ALL_TIME ? "全部时间"
                    : filterTime == FILTER_7D ? "近 7 天" : filterTime == FILTER_30D ? "近 30 天" : "近 90 天");

            // 趋势图
            List<Double> totals = new ArrayList<>();
            for (BalanceHistoryStore.HistoryItem it : items) totals.add(it.total);
            if (totals.size() >= 2) {
                chart.setValues(totals);
                chart.setVisibility(View.VISIBLE);
                tvEmpty.setVisibility(View.GONE);
            } else {
                chart.setVisibility(View.GONE);
                tvEmpty.setVisibility(View.VISIBLE);
            }

            // 月度统计
            if (!items.isEmpty()) {
                // Monthly stats
                java.util.LinkedHashMap<String, java.util.List<Double>> byMonth = new java.util.LinkedHashMap<>();
                SimpleDateFormat monthFmt = new SimpleDateFormat("yyyy-MM", Locale.getDefault());
                for (BalanceHistoryStore.HistoryItem it : items) {
                    String mk = monthFmt.format(new Date(it.ts));
                    java.util.List<Double> lst = byMonth.get(mk);
                    if (lst == null) { lst = new ArrayList<>(); byMonth.put(mk, lst); }
                    lst.add(it.total);
                }
                StringBuilder stats = new StringBuilder();
                for (java.util.Map.Entry<String, java.util.List<Double>> e : byMonth.entrySet()) {
                    java.util.List<Double> vals = e.getValue();
                    double last = vals.get(vals.size() - 1);
                    stats.append(e.getKey()).append(" x").append(vals.size())
                         .append(" end ").append(String.format(Locale.getDefault(), "%.2f", last)).append(" | ");
                }
                stats.append("total ").append(items.size()).append(" records / ").append(byMonth.size()).append(" months");
                tvStats.setText(stats.toString());
                tvStats.setVisibility(View.VISIBLE);
            } else {
                tvStats.setVisibility(View.GONE);
            }

            // 列表（倒序）
            historyContainer.removeAllViews();
            SimpleDateFormat sdf = new SimpleDateFormat("MM-dd HH:mm", Locale.getDefault());
            for (int i = items.size() - 1; i >= 0; i--) {
                BalanceHistoryStore.HistoryItem it = items.get(i);
                LinearLayout row = new LinearLayout(getActivity());
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(dp(16), dp(12), dp(16), dp(12));
                row.setBackgroundResource(R.drawable.bg_card_balance);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                lp.topMargin = dp(8);
                row.setLayoutParams(lp);

                TextView tvProvider = new TextView(getActivity());
                tvProvider.setText(ProviderConfig.get(it.providerId).name + "  ·  " + sdf.format(new Date(it.ts)));
                tvProvider.setTextColor(0xFF6750A4);
                tvProvider.setTextSize(12);
                tvProvider.setTypeface(null, android.graphics.Typeface.BOLD);
                row.addView(tvProvider);

                TextView tvBalance = new TextView(getActivity());
                tvBalance.setText(String.format(Locale.getDefault(),
                        "总额 %.2f %s    赠金 %.2f    充值 %.2f",
                        it.total, it.currency, it.granted, it.topped));
                tvBalance.setTextColor(0xFF1C1B1F);
                tvBalance.setTextSize(14);
                tvBalance.setPadding(0, dp(4), 0, 0);
                row.addView(tvBalance);

                historyContainer.addView(row);
            }
        } catch (Exception e) {
            tvEmpty.setText("历史数据加载失败: " + e.getMessage());
            tvEmpty.setVisibility(View.VISIBLE);
        }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
