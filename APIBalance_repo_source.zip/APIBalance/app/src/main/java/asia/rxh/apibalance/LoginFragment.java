package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 * ... (AGPLv3, see MainActivity)
 */

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Random;

public class LoginFragment extends Fragment {

    private EditText etApiKey, etCaptcha;
    private Switch swAutoLogin;
    private TextView[] btnProviders = new TextView[3];
    private TextView btnQuery;
    private TextView tvError;
    private ImageView ivLogo;
    private LinearLayout cardCaptcha;
    private TextView tvCaptchaQuestion;
    private View cardLogin;
    private boolean isQuerying = false;
    private int captchaAnswer;
    private int providerId = ProviderConfig.PROVIDER_DEEPSEEK;
    private Random random = new Random();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        etApiKey = view.findViewById(R.id.et_api_key);
        etCaptcha = view.findViewById(R.id.et_captcha);
        btnProviders[0] = view.findViewById(R.id.btn_provider_0);
        btnProviders[1] = view.findViewById(R.id.btn_provider_1);
        btnProviders[2] = view.findViewById(R.id.btn_provider_2);
        swAutoLogin = view.findViewById(R.id.sw_auto_login);
        btnQuery = view.findViewById(R.id.btn_query);
        tvError = view.findViewById(R.id.tv_error);
        ivLogo = view.findViewById(R.id.iv_logo);
        cardLogin = view.findViewById(R.id.card_login);
        cardCaptcha = view.findViewById(R.id.card_captcha);
        tvCaptchaQuestion = view.findViewById(R.id.tv_captcha_question);

        swAutoLogin.setChecked(true);

        // 服务商选择：自定义分段按钮
        MainActivity activity0 = (MainActivity) getActivity();
        if (activity0 != null) {
            providerId = activity0.getCurrentProviderId();
        }
        for (int i = 0; i < btnProviders.length; i++) {
            final int idx = i;
            btnProviders[i].setOnClickListener(v -> {
                selectProvider(idx);
            });
        }
        selectProvider(providerId);

        // Entrance animations
        ivLogo.setAlpha(0f);
        ivLogo.setScaleX(0.5f);
        ivLogo.setScaleY(0.5f);
        ivLogo.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(600)
                .setStartDelay(100)
                .setInterpolator(new OvershootInterpolator(1.2f))
                .start();

        cardLogin.setAlpha(0f);
        cardLogin.setTranslationY(100f);
        cardLogin.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(500)
                .setStartDelay(300)
                .setInterpolator(new OvershootInterpolator(0.8f))
                .start();

        btnQuery.setOnClickListener(v -> {
            if (isQuerying) return;
            String apiKey = etApiKey.getText().toString().trim();
            if (apiKey.isEmpty()) {
                showError(getString(R.string.err_empty_key));
                return;
            }
            if (!ProviderConfig.isValidKey(providerId, apiKey)) {
                showError(getString(R.string.err_bad_key));
                return;
            }
            // If captcha not shown yet → show it first
            if (cardCaptcha.getVisibility() != View.VISIBLE) {
                showCaptcha();
                return;
            }
            // Verify captcha
            String answerStr = etCaptcha.getText().toString().trim();
            if (answerStr.isEmpty()) {
                showError(getString(R.string.err_empty_captcha));
                return;
            }
            try {
                int answer = Integer.parseInt(answerStr);
                if (answer != captchaAnswer) {
                    // Wrong answer → new question
                    showError(getString(R.string.err_bad_captcha));
                    setRandomCaptcha();
                    etCaptcha.setText("");
                    return;
                }
            } catch (NumberFormatException e) {
                showError(getString(R.string.err_captcha_num));
                return;
            }
            doQuery(apiKey);
        });

        return view;
    }

    private void showCaptcha() {
        setRandomCaptcha();
        cardCaptcha.setVisibility(View.VISIBLE);
        cardCaptcha.setAlpha(0f);
        cardCaptcha.setTranslationY(30f);
        cardCaptcha.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(350)
                .setInterpolator(new OvershootInterpolator(0.6f))
                .start();
    }

    private void setRandomCaptcha() {
        int a = random.nextInt(11); // 0-10
        int b = random.nextInt(11); // 0-10
        captchaAnswer = a + b;
        tvCaptchaQuestion.setText(a + " + " + b + " = ?");
    }

    private void doQuery(String apiKey) {
        isQuerying = true;
        hideError();
        btnQuery.setText(R.string.querying);
        btnQuery.setAlpha(0.7f);
        btnQuery.setClickable(false);

        MainActivity activity = (MainActivity) getActivity();
        if (activity == null) return;

        activity.fetchBalance(apiKey, providerId, new MainActivity.OnBalanceFetchListener() {
            @Override
            public void onSuccess(int pid, ProviderConfig.BalanceResult result) {
                if (getActivity() == null) return;
                boolean autoLogin = swAutoLogin.isChecked();
                activity.onLoginSuccess(apiKey, pid, autoLogin);
                // 询问是否保存为账户（多账户）
                final int fpid = pid;
                final String fkey = apiKey;
                UiDialog.showInput(getActivity(), "保存为账户",
                        "账户名称（如：工作号）", "",
                        name -> {
                            if (!name.isEmpty()) {
                                AccountManager.saveAccount(getActivity().getApplicationContext(), fpid, name, fkey);
                                android.widget.Toast.makeText(getActivity(),
                                        "已保存账户：" + name, android.widget.Toast.LENGTH_SHORT).show();
                            }
                        });
            }

            @Override
            public void onError(String errorMessage) {
                if (getActivity() == null) return;
                isQuerying = false;
                btnQuery.setText(R.string.query_balance);
                btnQuery.setAlpha(1f);
                btnQuery.setClickable(true);
                showError(errorMessage);
                // Shake error
                tvError.setTranslationX(0f);
                tvError.animate()
                        .translationX(10f).setDuration(50)
                        .withEndAction(() -> tvError.animate()
                                .translationX(-10f).setDuration(50)
                                .withEndAction(() -> tvError.animate()
                                        .translationX(5f).setDuration(50)
                                        .withEndAction(() -> tvError.animate()
                                                .translationX(0f).setDuration(50).start())))
                        .start();
            }
        });
    }

    /** 切换选中的服务商按钮高亮。 */
    private void selectProvider(int idx) {
        providerId = idx;
        for (int i = 0; i < btnProviders.length; i++) {
            if (btnProviders[i] == null) continue;
            if (i == idx) {
                btnProviders[i].setBackgroundResource(R.drawable.bg_gradient_button);
                btnProviders[i].setTextColor(getResources().getColor(R.color.text_on_primary));
            } else {
                btnProviders[i].setBackgroundResource(R.drawable.bg_input_field);
                btnProviders[i].setTextColor(getResources().getColor(R.color.text_primary));
            }
        }
    }

    private void showError(String msg) {
        tvError.setText(msg);
        tvError.setVisibility(View.VISIBLE);
        tvError.setAlpha(0f);
        tvError.animate().alpha(1f).setDuration(200).start();
    }

    private void hideError() {
        tvError.animate().alpha(0f).setDuration(150)
                .withEndAction(() -> tvError.setVisibility(View.GONE)).start();
    }
}