package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 *
 * This file is part of APIBalance.
 *
 * APIBalance is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * APIBalance is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import java.util.Calendar;

/**
 * 峰谷价趣味卡片：
 *  - 梁文峰：工作日 09:00-12:00 / 14:00-18:00（峰时）
 *  - 梁文谷：其余时间 + 周末全天（谷时，5折特惠）
 */
public final class PeakOffpeak {

    private PeakOffpeak() {
    }

    public static boolean isPeak() {
        Calendar c = Calendar.getInstance();
        int day = c.get(Calendar.DAY_OF_WEEK);
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int minute = c.get(Calendar.MINUTE);
        boolean weekend = day == Calendar.SATURDAY || day == Calendar.SUNDAY;
        if (weekend) return false; // 周末全天谷时
        int minutes = hour * 60 + minute;
        // 09:00-12:00
        boolean morning = minutes >= 540 && minutes < 720;
        // 14:00-18:00
        boolean afternoon = minutes >= 840 && minutes < 1080;
        return morning || afternoon;
    }

    public static String name() {
        return isPeak() ? "梁文峰" : "梁文谷";
    }

    public static String iconText() {
        return isPeak() ? "峰时" : "谷时";
    }

    /** 俏皮话（不用 emoji）。 */
    public static String quip() {
        if (isPeak()) {
            String[] q = {
                "上班高峰，算力正忙，省着点用哦。",
                "峰时时段，Token 走得飞快，钱包有点紧张。",
                "现在是峰时，适合思考人生，不适合狂刷模型。"
            };
            return q[(int) (System.currentTimeMillis() / 1000 % q.length)];
        } else {
            String[] q = {
                "谷时到，五折特惠，随便造！",
                "夜深人静，算力便宜，正是刷模型的好时候。",
                "谷时特惠进行中，能省一半，抓紧用。",
                "周末谷时，价格腰斩，快乐加倍。"
            };
            return q[(int) (System.currentTimeMillis() / 1000 % q.length)];
        }
    }
}
