package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 *
 * This file is part of APIBalance.
 *
 * APIBalance is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * APIBalance is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/** 定时刷新：后台查询余额，低于阈值发通知。 */
public class AutoRefreshReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!AppPrefs.isAutoRefresh(context)) return;
        final Context ctx = context.getApplicationContext();

        int providerId = ctx.getSharedPreferences("ds_balance_prefs", 0)
                .getInt("provider_id", ProviderConfig.PROVIDER_DEEPSEEK);
        String key = CryptoManager.read(ctx, "provider_" + providerId + "_api_key");
        if (key == null || key.isEmpty()) return;

        new Thread(() -> {
            try {
                ProviderConfig.Provider p = ProviderConfig.get(providerId);
                HttpURLConnection conn = (HttpURLConnection) new URL(p.balanceUrl).openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Authorization", "Bearer " + key);
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(15000);
                int code = conn.getResponseCode();
                if (code == 200) {
                    BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = rd.readLine()) != null) sb.append(line);
                    rd.close();
                    ProviderConfig.BalanceResult result = p.parse(sb.toString());
                    double threshold = AppPrefs.getAlertThreshold(ctx);
                    if (AppPrefs.isAlertEnabled(ctx) && result.totalBalance < threshold) {
                        Notifier.notifyBalance(ctx, "余额不足提醒",
                                p.name + " 余额仅剩 " + String.format("%.2f %s", result.totalBalance, result.currency)
                                        + "，低于阈值 " + String.format("%.2f", threshold));
                    } else {
                        Notifier.notifyBalance(ctx, "定时刷新",
                                p.name + " 当前余额 " + String.format("%.2f %s", result.totalBalance, result.currency));
                    }
                }
                conn.disconnect();
            } catch (Exception ignored) {
            }
        }).start();
    }
}
