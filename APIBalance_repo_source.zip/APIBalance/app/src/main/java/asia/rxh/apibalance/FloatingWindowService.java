package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 *
 * This file is part of APIBalance.
 *
 * APIBalance is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * APIBalance is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** 桌面悬浮球：点击弹出最近余额。 */
public class FloatingWindowService extends Service {

    private WindowManager wm;
    private View floatBall;
    private View floatPanel;
    private WindowManager.LayoutParams ballParams;
    private WindowManager.LayoutParams panelParams;
    private int touchStartX, touchStartY;
    private int startX, startY;
    private boolean isDragging = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (floatBall == null) {
            createFloatBall();
        }
        return START_STICKY;
    }

    private void createFloatBall() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        int size = dp(48);
        ballParams = new WindowManager.LayoutParams(
                size, size,
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        ballParams.gravity = Gravity.TOP | Gravity.START;
        ballParams.x = dp(20);
        ballParams.y = dp(200);

        TextView ball = new TextView(this);
        ball.setText("¥");
        ball.setTextColor(0xFFFFFFFF);
        ball.setTextSize(18);
        ball.setGravity(Gravity.CENTER);
        ball.setBackgroundResource(R.drawable.bg_gradient_button);
        ball.setAlpha(0.9f);
        floatBall = ball;
        wm.addView(floatBall, ballParams);
        floatBall.setOnClickListener(v -> togglePanel());
        floatBall.setOnTouchListener(new View.OnTouchListener() {
            private int downX, downY;
            private long downTime;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = (int) e.getRawX();
                        downY = (int) e.getRawY();
                        startX = ballParams.x;
                        startY = ballParams.y;
                        downTime = System.currentTimeMillis();
                        isDragging = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawX() - downX) > 10 || Math.abs(e.getRawY() - downY) > 10) {
                            isDragging = true;
                            ballParams.x = startX + (int) (e.getRawX() - downX);
                            ballParams.y = startY + (int) (e.getRawY() - downY);
                            wm.updateViewLayout(floatBall, ballParams);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!isDragging && System.currentTimeMillis() - downTime < 300) {
                            togglePanel();
                        }
                        return true;
                }
                return false;
            }
        });
    }

    private void togglePanel() {
        if (floatPanel != null) {
            hidePanel();
            return;
        }
        showPanel();
    }

    private void showPanel() {
        panelParams = new WindowManager.LayoutParams(
                dp(240), WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = Math.max(8, ballParams.x - dp(30));
        panelParams.y = ballParams.y + dp(56);

        floatPanel = LayoutInflater.from(this).inflate(R.layout.float_panel, null);
        TextView tvBalance = floatPanel.findViewById(R.id.float_balance);
        TextView tvProvider = floatPanel.findViewById(R.id.float_provider);

        List<BalanceHistoryStore.HistoryItem> items = BalanceHistoryStore.getAll(this);
        if (!items.isEmpty()) {
            BalanceHistoryStore.HistoryItem last = items.get(items.size() - 1);
            String symbol = "CNY".equals(last.currency) ? "¥" : "$";
            tvBalance.setText(symbol + String.format("%.2f", last.total));
            tvProvider.setText(ProviderConfig.get(last.providerId).name);
        } else {
            tvBalance.setText("暂无数据");
            tvProvider.setText("查询余额后显示");
        }

        floatPanel.setOnClickListener(v -> {
            hidePanel();
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        });

        try {
            wm.addView(floatPanel, panelParams);
        } catch (Exception ignored) {
        }
    }

    private void hidePanel() {
        if (floatPanel != null) {
            try {
                wm.removeView(floatPanel);
            } catch (Exception ignored) {
            }
            floatPanel = null;
        }
    }

    @Override
    public void onDestroy() {
        if (floatBall != null) {
            try {
                wm.removeView(floatBall);
            } catch (Exception ignored) {
            }
            floatBall = null;
        }
        hidePanel();
        super.onDestroy();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
