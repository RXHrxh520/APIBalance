package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 *
 * This file is part of APIBalance.
 *
 * APIBalance is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class DebugFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_debug, container, false);

        TextView btnCrash = view.findViewById(R.id.btn_crash_test);
        btnCrash.setOnClickListener(v -> {
            throw new RuntimeException("crash test - manual exception");
        });

        TextView btnNetwork = view.findViewById(R.id.btn_network_test);
        btnNetwork.setOnClickListener(v -> runNetworkTest());

        TextView btnApi = view.findViewById(R.id.btn_api_test);
        btnApi.setOnClickListener(v -> runApiProbe());

        TextView btnKeyTest = view.findViewById(R.id.btn_key_test);
        if (btnKeyTest != null) {
            btnKeyTest.setOnClickListener(v -> runKeyTest());
        }

        TextView btnClearCache = view.findViewById(R.id.btn_clear_cache);
        if (btnClearCache != null) {
            btnClearCache.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act != null) {
                    try { act.getCacheDir().delete(); } catch (Exception ignored) {}
                    try { act.getExternalCacheDir().delete(); } catch (Exception ignored) {}
                    showResult("cache cleared");
                }
            });
        }

        TextView btnShowSettings = view.findViewById(R.id.btn_show_settings);
        if (btnShowSettings != null) {
            btnShowSettings.setOnClickListener(v -> showSettingsInfo());
        }

        view.setAlpha(0f);
        view.setTranslationY(24f);
        view.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(420)
                .setInterpolator(android.view.animation.AnimationUtils.loadInterpolator(getActivity(), android.R.interpolator.decelerate_cubic))
                .start();

        return view;
    }

    private void showResult(String text) {
        TextView tv = (TextView) getView().findViewById(R.id.tv_test_result);
        if (tv != null) {
            tv.setText(text);
            tv.setVisibility(View.VISIBLE);
        }
    }

    private void showSettingsInfo() {
        MainActivity act = (MainActivity) getActivity();
        if (act == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append("Provider: ").append(ProviderConfig.get(act.getCurrentProviderId()).name);
        sb.append(" | Theme: ").append(ThemePrefs.STYLE_NAMES[ThemePrefs.getStyle(act) % ThemePrefs.STYLE_NAMES.length]);
        sb.append(" | Timeout: ").append(AppPrefs.getTimeoutSec(act)).append("s");
        sb.append(" | Retry: ").append(AppPrefs.getRetryCount(act));
        sb.append(" | Proxy: ").append(AppPrefs.isProxyEnabled(act) ? AppPrefs.getProxyHost(act) + ":" + AppPrefs.getProxyPort(act) : "off");
        sb.append(" | Refresh: ").append(AppPrefs.getRefreshIntervalSec(act)).append("s");
        sb.append(" | Float: ").append(AppPrefs.isFloatWin(act) ? "on" : "off");
        sb.append(" | Lock: ").append(PrivacyPrefs.isLockEnabled(act) ? "on" : "off");
        showResult(sb.toString());
    }

    private void runNetworkTest() {
        showResult("testing network...");
        final String[] hosts = {
            "https://api.deepseek.com",
            "https://api.moonshot.ai",
            "https://open.bigmodel.cn"
        };
        new Thread(() -> {
            StringBuilder sb = new StringBuilder();
            for (String host : hosts) {
                long start = System.currentTimeMillis();
                String status;
                try {
                    HttpURLConnection conn = (HttpURLConnection) new URL(host).openConnection();
                    conn.setConnectTimeout(8000);
                    conn.setReadTimeout(8000);
                    int code = conn.getResponseCode();
                    long ms = System.currentTimeMillis() - start;
                    status = "ok (" + code + ", " + ms + "ms)";
                    conn.disconnect();
                } catch (Exception e) {
                    status = "fail: " + e.getClass().getSimpleName();
                }
                sb.append(host.replace("https://", "")).append("  ").append(status).append("\n");
            }
            final String result = sb.toString();
            if (getActivity() != null) {
                getActivity().runOnUiThread(() -> showResult(result));
            }
        }).start();
    }

    private void runApiProbe() {
        showResult("probing endpoints...");
        new Thread(() -> {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < ProviderConfig.count(); i++) {
                ProviderConfig.Provider p = ProviderConfig.get(i);
                String status;
                try {
                    HttpURLConnection conn = (HttpURLConnection) new URL(p.balanceUrl).openConnection();
                    conn.setRequestMethod("GET");
                    conn.setRequestProperty("Authorization", "Bearer test-invalid-key");
                    conn.setConnectTimeout(8000);
                    conn.setReadTimeout(8000);
                    int code = conn.getResponseCode();
                    status = (code == 401 || code == 403) ? "endpoint ok (" + code + ")" : "resp " + code;
                    conn.disconnect();
                } catch (Exception e) {
                    status = "unreachable: " + e.getClass().getSimpleName();
                }
                sb.append(p.name).append("  ").append(status).append("\n");
            }
            final String result = sb.toString();
            if (getActivity() != null) {
                getActivity().runOnUiThread(() -> showResult(result));
            }
        }).start();
    }

    private void runKeyTest() {
        MainActivity act = (MainActivity) getActivity();
        if (act == null) return;
        final int pid = act.getCurrentProviderId();
        final String key = act.getCurrentApiKey();
        if (key == null || key.isEmpty()) {
            showResult("no API key to test");
            return;
        }
        showResult("testing key for " + ProviderConfig.get(pid).name + "...");
        act.fetchBalance(key, pid, new MainActivity.OnBalanceFetchListener() {
            @Override
            public void onSuccess(int pid2, ProviderConfig.BalanceResult result) {
                showResult("key OK! " + ProviderConfig.get(pid2).name + " balance: "
                        + String.format("%.2f %s", result.totalBalance, result.currency));
            }

            @Override
            public void onError(String errorMessage) {
                showResult("key test failed: " + errorMessage);
            }
        });
    }
}
