package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 *
 * This file is part of APIBalance.
 *
 * APIBalance is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * APIBalance is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 余额历史记录：把每次查询结果保存为本地快照，供趋势页展示。
 * 数据格式：JSON 数组 [{ts, provider, currency, total, granted, topped}, ...]
 */
public final class BalanceHistoryStore {

    private static final String PREFS = "ds_balance_history";
    private static final String KEY_DATA = "history";
    private static final int MAX_ITEMS = 200;

    private BalanceHistoryStore() {
    }

    public static void add(Context ctx, int providerId, ProviderConfig.BalanceResult result) {
        try {
            SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString(KEY_DATA, "[]"));
            JSONObject item = new JSONObject();
            item.put("ts", System.currentTimeMillis());
            item.put("provider", providerId);
            item.put("currency", result.currency);
            item.put("total", result.totalBalance);
            item.put("granted", result.grantedBalance);
            item.put("topped", result.toppedUpBalance);
            arr.put(item);
            // 只保留最近 MAX_ITEMS 条
            while (arr.length() > MAX_ITEMS) {
                arr.remove(0);
            }
            sp.edit().putString(KEY_DATA, arr.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    /** 返回全部历史（按时间升序）。 */
    public static List<HistoryItem> getAll(Context ctx) {
        List<HistoryItem> list = new ArrayList<>();
        try {
            SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString(KEY_DATA, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                HistoryItem it = new HistoryItem();
                it.ts = o.optLong("ts", 0);
                it.providerId = o.optInt("provider", ProviderConfig.PROVIDER_DEEPSEEK);
                it.currency = o.optString("currency", "CNY");
                it.total = o.optDouble("total", 0);
                it.granted = o.optDouble("granted", 0);
                it.topped = o.optDouble("topped", 0);
                list.add(it);
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    public static void clear(Context ctx) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_DATA).apply();
    }

    public static final class HistoryItem {
        public long ts;
        public int providerId;
        public String currency;
        public double total;
        public double granted;
        public double topped;
    }
}
