package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 *
 * This file is part of APIBalance.
 *
 * APIBalance is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * APIBalance is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import android.content.Context;
import android.content.SharedPreferences;

/** 隐私/锁屏设置：指纹锁、隐藏余额、密码等。 */
public final class PrivacyPrefs {

    private static final String PREFS = "ds_privacy";
    private static final String KEY_LOCK = "lock_enabled";
    private static final String KEY_HIDE_BALANCE = "hide_balance";
    private static final String KEY_PASSWORD = "lock_password";

    private PrivacyPrefs() {
    }

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean isLockEnabled(Context c) {
        return sp(c).getBoolean(KEY_LOCK, false);
    }

    public static void setLockEnabled(Context c, boolean b) {
        sp(c).edit().putBoolean(KEY_LOCK, b).apply();
    }

    public static boolean isHideBalance(Context c) {
        return sp(c).getBoolean(KEY_HIDE_BALANCE, false);
    }

    public static void setHideBalance(Context c, boolean b) {
        sp(c).edit().putBoolean(KEY_HIDE_BALANCE, b).apply();
    }

    public static String getPassword(Context c) {
        return sp(c).getString(KEY_PASSWORD, null);
    }

    public static void setPassword(Context c, String pw) {
        sp(c).edit().putString(KEY_PASSWORD, pw).apply();
    }
}
