package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 *
 * This file is part of APIBalance.
 *
 * APIBalance is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * APIBalance is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * 自定义 UI 弹窗：圆角卡片风格，替代系统 AlertDialog。
 * 支持：单选列表 / 双按钮确认 / 文本输入。
 */
public final class UiDialog {

    private UiDialog() {
    }

    public interface OnPickListener {
        void onPick(int index);
    }

    public interface OnConfirmListener {
        void onConfirm();
    }

    /** 单选列表弹窗。 */
    public static void showPicker(Context ctx, String title, String[] options, int selected, OnPickListener l) {
        Dialog d = baseDialog(ctx);
        TextView titleView = d.findViewById(R.id.dialog_title);
        LinearLayout opts = d.findViewById(R.id.dialog_options);
        titleView.setText(title);

        for (int i = 0; i < options.length; i++) {
            final int idx = i;
            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(ctx, 14), dp(ctx, 12), dp(ctx, 14), dp(ctx, 12));
            row.setBackgroundResource(R.drawable.bg_input_field);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            if (i > 0) lp.topMargin = dp(ctx, 8);
            row.setLayoutParams(lp);

            TextView tv = new TextView(ctx);
            tv.setText(options[i]);
            tv.setTextSize(15);
            tv.setTextColor(ctx.getResources().getColor(R.color.text_primary));
            LinearLayout.LayoutParams tvLp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            tv.setLayoutParams(tvLp);
            row.addView(tv);

            if (i == selected) {
                TextView dot = new TextView(ctx);
                dot.setText("✓");
                dot.setTextColor(ctx.getResources().getColor(R.color.primary));
                dot.setTextSize(16);
                dot.setTypeface(null, android.graphics.Typeface.BOLD);
                row.addView(dot);
            }

            final Dialog fd = d;
            row.setOnClickListener(v -> {
                if (l != null) l.onPick(idx);
                fd.dismiss();
            });
            opts.addView(row);
        }

        TextView neg = d.findViewById(R.id.dialog_negative);
        neg.setVisibility(View.GONE);
        d.findViewById(R.id.dialog_positive).setVisibility(View.GONE);
        d.show();
    }

    /** 双按钮确认弹窗（可带 message）。 */
    public static void showConfirm(Context ctx, String title, String message,
                                   String posText, String negText,
                                   OnConfirmListener pos, OnConfirmListener neg) {
        Dialog d = baseDialog(ctx);
        TextView titleView = d.findViewById(R.id.dialog_title);
        TextView msg = d.findViewById(R.id.dialog_message);
        TextView posBtn = d.findViewById(R.id.dialog_positive);
        TextView negBtn = d.findViewById(R.id.dialog_negative);
        titleView.setText(title);
        if (message != null) {
            msg.setText(message);
            msg.setVisibility(View.VISIBLE);
        }
        if (posText != null) posBtn.setText(posText);
        if (negText != null) negBtn.setText(negText);
        posBtn.setOnClickListener(v -> {
            if (pos != null) pos.onConfirm();
            d.dismiss();
        });
        negBtn.setOnClickListener(v -> {
            if (neg != null) neg.onConfirm();
            d.dismiss();
        });
        d.show();
    }

    /** 文本输入弹窗（单输入框）。 */
    public static void showInput(Context ctx, String title, String hint, String initial,
                                 final OnInputListener l) {
        Dialog d = baseDialog(ctx);
        TextView titleView = d.findViewById(R.id.dialog_title);
        LinearLayout inputArea = d.findViewById(R.id.dialog_input_area);
        titleView.setText(title);

        final EditText et = new EditText(ctx);
        et.setHint(hint);
        et.setText(initial == null ? "" : initial);
        et.setBackgroundResource(R.drawable.bg_input_field);
        et.setTextColor(ctx.getResources().getColor(R.color.text_primary));
        et.setHintTextColor(ctx.getResources().getColor(R.color.text_hint));
        et.setTextSize(15);
        et.setPadding(dp(ctx, 14), dp(ctx, 10), dp(ctx, 14), dp(ctx, 10));
        inputArea.addView(et);
        inputArea.setVisibility(View.VISIBLE);

        TextView posBtn = d.findViewById(R.id.dialog_positive);
        posBtn.setOnClickListener(v -> {
            if (l != null) l.onInput(et.getText().toString().trim());
            d.dismiss();
        });
        d.show();
    }

    public interface OnInputListener {
        void onInput(String text);
    }

    private static Dialog baseDialog(Context ctx) {
        Dialog d = new Dialog(ctx);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setContentView(R.layout.dialog_custom);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new GradientDrawable());
            w.setLayout(dp(ctx, 320), ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setGravity(Gravity.CENTER);
        }
        return d;
    }

    private static int dp(Context c, int v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }
}
