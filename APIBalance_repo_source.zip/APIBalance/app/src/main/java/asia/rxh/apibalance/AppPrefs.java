package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 *
 * This file is part of APIBalance.
 *
 * APIBalance is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * APIBalance is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 统一设置项管理：超时、重试、主题、隐私开关、多币种、汇率等。
 * 避免设置项散落在各个类里。
 */
public final class AppPrefs {

    private static final String PREFS = "ds_settings";

    private static final String KEY_TIMEOUT = "timeout_sec";
    private static final String KEY_RETRY = "retry_count";
    private static final String KEY_CURRENCY = "display_currency"; // 0=自动 1=CNY 2=USD
    private static final String KEY_PROXY = "proxy_enabled";
    private static final String KEY_PROXY_HOST = "proxy_host";
    private static final String KEY_PROXY_PORT = "proxy_port";
    private static final String KEY_NO_SCREENSHOT = "priv_noscreenshot";
    private static final String KEY_NO_NOTIFY = "priv_nonotify";
    private static final String KEY_HIDE_RECENTS = "priv_hiderecents";
    private static final String KEY_ALERT_ENABLED = "alert_enabled";
    private static final String KEY_ALERT_THRESHOLD = "alert_threshold";
    private static final String KEY_AUTO_REFRESH = "auto_refresh";
    private static final String KEY_QUIET_START = "quiet_start";
    private static final String KEY_QUIET_END = "quiet_end";
    private static final String KEY_QUIET_ENABLED = "quiet_enabled";
    private static final String KEY_STICKY_NOTIFY = "sticky_notify";
    private static final String KEY_TLS_VERIFY = "tls_verify";
    private static final String KEY_USER_AGENT = "user_agent";
    private static final String KEY_REQ_LOG = "req_log";
    private static final String KEY_FONT_SIZE = "font_size"; // 0=小 1=中 2=大
    private static final String KEY_BG_PATH = "bg_path";
    private static final String KEY_FLOAT = "float_win";
    private static final String KEY_REFRESH_INTERVAL = "refresh_interval_sec";

    private AppPrefs() {
    }

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // ---- 超时/重试 ----
    public static int getTimeoutSec(Context c) {
        return sp(c).getInt(KEY_TIMEOUT, 15);
    }

    public static void setTimeoutSec(Context c, int sec) {
        sp(c).edit().putInt(KEY_TIMEOUT, sec).apply();
    }

    public static int getRetryCount(Context c) {
        return sp(c).getInt(KEY_RETRY, 0);
    }

    public static void setRetryCount(Context c, int n) {
        sp(c).edit().putInt(KEY_RETRY, n).apply();
    }

    // ---- 多币种显示 ----
    public static int getDisplayCurrency(Context c) {
        return sp(c).getInt(KEY_CURRENCY, 0);
    }

    public static void setDisplayCurrency(Context c, int mode) {
        sp(c).edit().putInt(KEY_CURRENCY, mode).apply();
    }

    // ---- 代理 ----
    public static boolean isProxyEnabled(Context c) {
        return sp(c).getBoolean(KEY_PROXY, false);
    }

    public static void setProxyEnabled(Context c, boolean b) {
        sp(c).edit().putBoolean(KEY_PROXY, b).apply();
    }

    public static String getProxyHost(Context c) {
        return sp(c).getString(KEY_PROXY_HOST, "127.0.0.1");
    }

    public static void setProxyHost(Context c, String h) {
        sp(c).edit().putString(KEY_PROXY_HOST, h).apply();
    }

    public static int getProxyPort(Context c) {
        return sp(c).getInt(KEY_PROXY_PORT, 7890);
    }

    public static void setProxyPort(Context c, int p) {
        sp(c).edit().putInt(KEY_PROXY_PORT, p).apply();
    }

    // ---- 隐私开关 ----
    public static boolean noScreenshot(Context c) {
        return sp(c).getBoolean(KEY_NO_SCREENSHOT, false);
    }

    public static void setNoScreenshot(Context c, boolean b) {
        sp(c).edit().putBoolean(KEY_NO_SCREENSHOT, b).apply();
    }

    public static boolean noNotify(Context c) {
        return sp(c).getBoolean(KEY_NO_NOTIFY, false);
    }

    public static void setNoNotify(Context c, boolean b) {
        sp(c).edit().putBoolean(KEY_NO_NOTIFY, b).apply();
    }

    public static boolean hideRecents(Context c) {
        return sp(c).getBoolean(KEY_HIDE_RECENTS, false);
    }

    public static void setHideRecents(Context c, boolean b) {
        sp(c).edit().putBoolean(KEY_HIDE_RECENTS, b).apply();
    }

    // ---- 余额提醒 ----
    public static boolean isAlertEnabled(Context c) {
        return sp(c).getBoolean(KEY_ALERT_ENABLED, false);
    }

    public static void setAlertEnabled(Context c, boolean b) {
        sp(c).edit().putBoolean(KEY_ALERT_ENABLED, b).apply();
    }

    public static double getAlertThreshold(Context c) {
        return sp(c).getFloat(KEY_ALERT_THRESHOLD, 10f);
    }

    public static void setAlertThreshold(Context c, double v) {
        sp(c).edit().putFloat(KEY_ALERT_THRESHOLD, (float) v).apply();
    }

    // ---- 定时刷新 ----
    public static boolean isAutoRefresh(Context c) {
        return sp(c).getBoolean(KEY_AUTO_REFRESH, false);
    }

    public static void setAutoRefresh(Context c, boolean b) {
        sp(c).edit().putBoolean(KEY_AUTO_REFRESH, b).apply();
    }

    // ---- 静音时段 ----
    public static boolean isQuietEnabled(Context c) {
        return sp(c).getBoolean(KEY_QUIET_ENABLED, false);
    }

    public static void setQuietEnabled(Context c, boolean b) {
        sp(c).edit().putBoolean(KEY_QUIET_ENABLED, b).apply();
    }

    public static int getQuietStart(Context c) {
        return sp(c).getInt(KEY_QUIET_START, 23); // 23:00
    }

    public static void setQuietStart(Context c, int h) {
        sp(c).edit().putInt(KEY_QUIET_START, h).apply();
    }

    public static int getQuietEnd(Context c) {
        return sp(c).getInt(KEY_QUIET_END, 7); // 07:00
    }

    public static void setQuietEnd(Context c, int h) {
        sp(c).edit().putInt(KEY_QUIET_END, h).apply();
    }

    /** 当前是否处于静音时段。 */
    public static boolean inQuietHours(Context c) {
        if (!isQuietEnabled(c)) return false;
        int now = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
        int start = getQuietStart(c);
        int end = getQuietEnd(c);
        if (start <= end) {
            return now >= start && now < end;
        } else {
            return now >= start || now < end; // 跨午夜
        }
    }

    // ---- 常驻通知 ----
    public static boolean isStickyNotify(Context c) {
        return sp(c).getBoolean(KEY_STICKY_NOTIFY, false);
    }

    public static void setStickyNotify(Context c, boolean b) {
        sp(c).edit().putBoolean(KEY_STICKY_NOTIFY, b).apply();
    }

    // ---- TLS / UA / 日志 ----
    public static boolean isTlsVerify(Context c) {
        return sp(c).getBoolean(KEY_TLS_VERIFY, true);
    }

    public static void setTlsVerify(Context c, boolean b) {
        sp(c).edit().putBoolean(KEY_TLS_VERIFY, b).apply();
    }

    public static String getUserAgent(Context c) {
        return sp(c).getString(KEY_USER_AGENT, "APIBalance/" + BuildConfig.VERSION_NAME);
    }

    public static void setUserAgent(Context c, String ua) {
        sp(c).edit().putString(KEY_USER_AGENT, ua).apply();
    }

    public static boolean isReqLog(Context c) {
        return sp(c).getBoolean(KEY_REQ_LOG, false);
    }

    public static void setReqLog(Context c, boolean b) {
        sp(c).edit().putBoolean(KEY_REQ_LOG, b).apply();
    }

    // ---- 字体大小 ----
    public static int getFontSize(Context c) {
        return sp(c).getInt(KEY_FONT_SIZE, 1);
    }

    public static void setFontSize(Context c, int v) {
        sp(c).edit().putInt(KEY_FONT_SIZE, v).apply();
    }

    /** 字体缩放系数。 */
    public static float getFontScale(Context c) {
        int v = getFontSize(c);
        return v == 0 ? 0.9f : v == 2 ? 1.2f : 1.0f;
    }

    // ---- 自定义背景 ----
    public static String getBgPath(Context c) {
        return sp(c).getString(KEY_BG_PATH, null);
    }

    public static void setBgPath(Context c, String p) {
        sp(c).edit().putString(KEY_BG_PATH, p).apply();
    }

    // ---- 悬浮窗 ----
    public static boolean isFloatWin(Context c) {
        return sp(c).getBoolean(KEY_FLOAT, false);
    }

    public static void setFloatWin(Context c, boolean b) {
        sp(c).edit().putBoolean(KEY_FLOAT, b).apply();
    }

    // ---- 刷新间隔（秒）----
    public static int getRefreshIntervalSec(Context c) {
        return sp(c).getInt(KEY_REFRESH_INTERVAL, 3600); // 默认 1 小时
    }

    public static void setRefreshIntervalSec(Context c, int sec) {
        sp(c).edit().putInt(KEY_REFRESH_INTERVAL, sec).apply();
    }
}