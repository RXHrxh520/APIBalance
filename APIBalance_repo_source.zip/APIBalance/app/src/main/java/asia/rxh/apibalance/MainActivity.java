package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 *
 * This file is part of APIBalance.
 *
 * APIBalance is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * APIBalance is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {

    private static final String PREFS_NAME = "ds_balance_prefs";
    private static final String KEY_API_KEY = "api_key";
    private static final String KEY_PROVIDER = "provider_id";
    private static final String KEY_AUTO_LOGIN = "auto_login";
    private static final String KEY_THEME = "theme_mode"; // 0=跟随系统 1=浅色 2=深色
    private static final String PREFS_DEBUG = "ds_debug_prefs";
    private static final String KEY_DEBUG = "debug_enabled";

    private int currentProviderId = ProviderConfig.PROVIDER_DEEPSEEK;
    private String currentApiKey;
    private Handler mainHandler;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // 主题：0=跟随系统 1=浅色 2=深色
        // 关键：Android 的 @color/* 资源（values-night）跟随"系统"uiMode，而非 App 主题。
        // 所以必须手动覆盖 Configuration.uiMode，强制资源按所选模式解析，浅色/深色才能真正生效。
        int themeMode = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getInt(KEY_THEME, 0);
        int nightFlag;
        if (themeMode == 2) {
            nightFlag = Configuration.UI_MODE_NIGHT_YES;
        } else if (themeMode == 1) {
            nightFlag = Configuration.UI_MODE_NIGHT_NO;
        } else {
            nightFlag = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        }
        Configuration cfg = new Configuration(getResources().getConfiguration());
        cfg.uiMode = (cfg.uiMode & ~Configuration.UI_MODE_NIGHT_MASK) | nightFlag;
        getResources().updateConfiguration(cfg, getResources().getDisplayMetrics());
        setTheme(nightFlag == Configuration.UI_MODE_NIGHT_YES
                ? R.style.RxHTheme_Dark
                : R.style.RxHTheme_FollowSystem);

        super.onCreate(savedInstanceState);

        // 字体大小
        float scale = AppPrefs.getFontScale(this);
        if (scale != 1.0f) {
            Configuration cfg2 = new Configuration(getResources().getConfiguration());
            cfg2.fontScale = scale;
            getResources().updateConfiguration(cfg2, getResources().getDisplayMetrics());
        }

        setContentView(R.layout.activity_main);
        applyThemeBars();

        // 主题背景（Code CLI / 复古2000 深色）
        int themeBg = ThemePrefs.getBackground(this);
        if (themeBg != 0) {
            View rootView = findViewById(R.id.container);
            if (rootView != null) rootView.setBackgroundColor(themeBg);
        }

        // 自定义背景
        String bgPath = AppPrefs.getBgPath(this);
        if (bgPath != null) {
            try {
                View root = findViewById(R.id.container);
                if (root != null) {
                    root.setBackground(android.graphics.drawable.Drawable.createFromStream(
                            getContentResolver().openInputStream(android.net.Uri.parse(bgPath)), null));
                }
            } catch (Exception ignored) {
            }
        }
        mainHandler = new Handler(Looper.getMainLooper());

        // Install crash handler
        CrashHandler.install(getApplicationContext());

        // Check for pending crash
        if (CrashHandler.hasPendingCrash(getApplicationContext())) {
            String[] crashInfo = CrashHandler.getCrashInfo(getApplicationContext());
            Intent crashIntent = new Intent(this, CrashActivity.class);
            crashIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            crashIntent.putExtra("crash_message", crashInfo[0]);
            crashIntent.putExtra("crash_trace", crashInfo[1]);
            startActivity(crashIntent);
            finish();
            return;
        }

        // Immersive status bar
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            window.setStatusBarColor(android.graphics.Color.TRANSPARENT);
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        } else {
            window.setStatusBarColor(0x00000000);
        }

        applyPrivacyFlags();

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Startup open-source notice (show once)
        if (!prefs.getBoolean("oss_notice_shown", false)) {
            prefs.edit().putBoolean("oss_notice_shown", true).apply();
            UiDialog.showConfirm(this, "开源声明",
                    "本软件永远开源免费！\n\n如果您是付费购买的，请立即联系对应方退款。如拒不退款，请联系项目原作者协助（无法保证百分百）。\n\n该项目基于AGPLv3协议开源\n项目地址:\nhttps://github.com/RXHrxh520/APIBalance\n\n感谢您的支持！",
                    "我知道了", null, null, null);
        }

        currentProviderId = prefs.getInt(KEY_PROVIDER, ProviderConfig.PROVIDER_DEEPSEEK);

        boolean autoLogin = prefs.getBoolean(KEY_AUTO_LOGIN, false);
        String savedKey = CryptoManager.read(this, getProviderKeyName(currentProviderId));

        if (autoLogin && savedKey != null && !savedKey.isEmpty()) {
            currentApiKey = savedKey;
            if (PrivacyPrefs.isLockEnabled(this)) {
                // 有锁：先显示锁屏，解锁后进入余额页
                showLockFragment();
            } else {
                showBalanceFragment(savedKey, currentProviderId, false);
            }
        } else {
            showLoginFragment(false);
        }
    }

    public void showLockFragment() {
        LockFragment frag = new LockFragment();
        getFragmentManager().beginTransaction()
                .replace(R.id.container, frag)
                .commit();
    }

    /** 锁屏验证通过：进入余额页。 */
    public void onLockPassed() {
        if (currentApiKey != null && !currentApiKey.isEmpty()) {
            showBalanceFragment(currentApiKey, currentProviderId, true);
        } else {
            showLoginFragment(true);
        }
    }

    public void showLoginFragment(boolean animate) {
        LoginFragment frag = new LoginFragment();
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        if (animate) {
            ft.setCustomAnimations(R.animator.slide_in_left, R.animator.slide_out_right);
        }
        ft.replace(R.id.container, frag).commit();
    }

    public void showBalanceFragment(String apiKey, int providerId, boolean animate) {
        currentApiKey = apiKey;
        currentProviderId = providerId;
        BalanceFragment frag = BalanceFragment.newInstance(apiKey, providerId);
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        if (animate) {
            ft.setCustomAnimations(R.animator.slide_in_right, R.animator.slide_out_left);
        }
        ft.replace(R.id.container, frag).commit();
    }

    public void showSettingsFragment() {
        SettingsFragment frag = new SettingsFragment();
        getFragmentManager()
                .beginTransaction()
                .setCustomAnimations(R.animator.slide_in_right, R.animator.slide_out_left)
                .replace(R.id.container, frag)
                .addToBackStack(null)
                .commit();
    }

    public void showHistoryFragment() {
        HistoryFragment frag = new HistoryFragment();
        getFragmentManager()
                .beginTransaction()
                .setCustomAnimations(R.animator.slide_in_right, R.animator.slide_out_left)
                .replace(R.id.container, frag)
                .addToBackStack(null)
                .commit();
    }

    public void showAboutFragment() {
        AboutFragment frag = new AboutFragment();
        getFragmentManager()
                .beginTransaction()
                .setCustomAnimations(R.animator.slide_in_right, R.animator.slide_out_left)
                .replace(R.id.container, frag)
                .addToBackStack(null)
                .commit();
    }

    public void showDebugFragment() {
        DebugFragment frag = new DebugFragment();
        getFragmentManager()
                .beginTransaction()
                .setCustomAnimations(R.animator.slide_in_right, R.animator.slide_out_left)
                .replace(R.id.container, frag)
                .addToBackStack(null)
                .commit();
    }

    /** 快捷切换服务商：若该服务商已保存 Key 则直接切换，否则回登录页。 */
    public void switchProviderQuick(int newProviderId) {
        String savedKey = CryptoManager.read(this, getProviderKeyName(newProviderId));
        if (savedKey != null && !savedKey.isEmpty()) {
            currentApiKey = savedKey;
            currentProviderId = newProviderId;
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .edit().putInt(KEY_PROVIDER, newProviderId).apply();
            showBalanceFragment(savedKey, newProviderId, true);
        } else {
            // 没有该服务商的 Key，回登录页选择
            currentProviderId = newProviderId;
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .edit().putInt(KEY_PROVIDER, newProviderId).apply();
            showLoginFragment(true);
        }
    }

    /** 应用隐私标志：禁止截屏 / 隐藏最近任务。 */
    public void applyPrivacyFlags() {
        if (AppPrefs.noScreenshot(this) || PrivacyPrefs.isLockEnabled(this)) {
            getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
        } else {
            getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
        }
    }

    /** 开启/关闭定时刷新（每小时后台查询余额）。 */
    public void scheduleAutoRefresh(boolean enable) {
        android.app.AlarmManager am = (android.app.AlarmManager) getSystemService(ALARM_SERVICE);
        Intent i = new Intent(this, AutoRefreshReceiver.class);
        android.app.PendingIntent pi = android.app.PendingIntent.getBroadcast(this, 0, i,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE);
        if (enable) {
            long interval = AppPrefs.getRefreshIntervalSec(this) * 1000L;
            long first = System.currentTimeMillis() + 60 * 1000L; // 1 分钟后首次
            am.setInexactRepeating(android.app.AlarmManager.RTC_WAKEUP, first, interval, pi);
        } else {
            am.cancel(pi);
        }
    }

    /** 用最近余额刷新常驻通知。 */
    public void showStickyNotify() {
        java.util.List<BalanceHistoryStore.HistoryItem> items =
                BalanceHistoryStore.getAll(this);
        if (!items.isEmpty()) {
            BalanceHistoryStore.HistoryItem last = items.get(items.size() - 1);
            String symbol = "CNY".equals(last.currency) ? "¥" : "$";
            Notifier.showSticky(this, ProviderConfig.get(last.providerId).name,
                    symbol + String.format("%.2f", last.total));
        } else {
            Notifier.showSticky(this, "APIBalance", "暂无数据");
        }
    }

    /** 按主题风格设置状态栏/导航栏颜色。 */
    public void applyThemeBars() {
        int accent = ThemePrefs.getColor(this);
        int style = ThemePrefs.getStyle(this);
        boolean dark = ThemePrefs.usesDarkBg(this);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(ThemePrefs.getBackground(this) != 0
                    ? ThemePrefs.getBackground(this) : 0xFFF6F3FA);
            getWindow().setNavigationBarColor(dark ? 0xFF0D1117 : 0xFFFFFFFF);
        }
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            getWindow().getDecorView().setSystemUiVisibility(dark
                    ? View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    : View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
    }

    public boolean isDebugEnabled() {
        return getSharedPreferences(PREFS_DEBUG, MODE_PRIVATE).getBoolean(KEY_DEBUG, false);
    }

    /** 登录/选择服务商成功后调用：加密保存 Key，记录服务商。 */
    public void onLoginSuccess(String apiKey, int providerId, boolean autoLogin) {
        currentApiKey = apiKey;
        currentProviderId = providerId;
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(KEY_AUTO_LOGIN, autoLogin);
        editor.putInt(KEY_PROVIDER, providerId);
        if (autoLogin) {
            CryptoManager.save(this, getProviderKeyName(providerId), apiKey);
        } else {
            CryptoManager.remove(this, getProviderKeyName(providerId));
        }
        editor.apply();
        showBalanceFragment(apiKey, providerId, true);
    }

    public void onChangeKey() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().remove(KEY_AUTO_LOGIN).apply();
        CryptoManager.remove(this, getProviderKeyName(currentProviderId));
        currentApiKey = null;
        showLoginFragment(true);
    }

    /** 设置主题模式：0=跟随系统 1=浅色 2=深色，设置后重建生效。 */
    public void setThemeMode(int mode) {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putInt(KEY_THEME, mode).apply();
        recreate();
    }

    public int getThemeMode() {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getInt(KEY_THEME, 0);
    }

    public String getCurrentApiKey() {
        return currentApiKey;
    }

    public int getCurrentProviderId() {
        return currentProviderId;
    }

    /** SharedPreferences 里按服务商区分 Key 的存储名。 */
    public String getProviderKeyName(int providerId) {
        return "provider_" + providerId + "_" + KEY_API_KEY;
    }

    /** 清除某服务商已保存的 Key（用于切换时避免残留）。 */
    public void clearProviderKey(int providerId) {
        CryptoManager.remove(this, getProviderKeyName(providerId));
    }

    public void animateCardEntrance(View view, int delay) {
        view.setAlpha(0f);
        view.setTranslationY(80f);
        view.setScaleX(0.9f);
        view.setScaleY(0.9f);
        view.animate()
                .alpha(1f)
                .translationY(0f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(500)
                .setStartDelay(delay)
                .setInterpolator(android.view.animation.AnimationUtils.loadInterpolator(this, R.interpolator.anticipate_overshoot))
                .start();
    }

    public void animateNumberCount(TextView tv, double from, double to, String prefix, String suffix) {
        ValueAnimator anim = ValueAnimator.ofFloat((float) from, (float) to);
        anim.setDuration(1000);
        anim.setInterpolator(android.view.animation.AnimationUtils.loadInterpolator(this, R.interpolator.fast_out_slow_in));
        anim.addUpdateListener(animation -> {
            float val = (float) animation.getAnimatedValue();
            tv.setText(String.format("%s%.2f%s", prefix, val, suffix));
        });
        anim.start();
    }

    /**
     * 按服务商请求余额并解析为统一模型。
     * 成功回调 {@link OnBalanceFetchListener#onSuccess(int, ProviderConfig.BalanceResult)}。
     */
    public void fetchBalance(final String apiKey, final int providerId, final OnBalanceFetchListener listener) {
        final int timeoutSec = AppPrefs.getTimeoutSec(this);
        final int retryCount = AppPrefs.getRetryCount(this);
        new Thread(() -> {
            int attempt = 0;
            while (true) {
                HttpURLConnection conn = null;
                try {
                    ProviderConfig.Provider provider = ProviderConfig.get(providerId);
                    URL url = new URL(provider.balanceUrl);
                    conn = (HttpURLConnection) url.openConnection();
                    if (AppPrefs.isProxyEnabled(MainActivity.this)) {
                        java.net.Proxy proxy = new java.net.Proxy(
                                java.net.Proxy.Type.HTTP,
                                new java.net.InetSocketAddress(
                                        AppPrefs.getProxyHost(MainActivity.this),
                                        AppPrefs.getProxyPort(MainActivity.this)));
                        conn = (HttpURLConnection) url.openConnection(proxy);
                    }
                    conn.setRequestMethod("GET");
                    conn.setRequestProperty("Authorization", "Bearer " + apiKey);
                    conn.setRequestProperty("Accept", "application/json");
                    conn.setRequestProperty("User-Agent", AppPrefs.getUserAgent(MainActivity.this));
                    if (!AppPrefs.isTlsVerify(MainActivity.this)) {
                        disableTlsVerify(conn);
                    }
                    if (AppPrefs.isReqLog(MainActivity.this)) {
                        android.util.Log.d("APIBalance", "REQ " + provider.balanceUrl + " timeout=" + timeoutSec + "s retry=" + retryCount);
                    }
                    conn.setConnectTimeout(timeoutSec * 1000);
                    conn.setReadTimeout(timeoutSec * 1000);

                    int responseCode = conn.getResponseCode();

                    if (responseCode == 200) {
                        BufferedReader reader = new BufferedReader(
                                new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            sb.append(line);
                        }
                        reader.close();
                        String json = sb.toString();
                        try {
                            ProviderConfig.BalanceResult result = provider.parse(json);
                            mainHandler.post(() -> listener.onSuccess(providerId, result));
                        } catch (Exception parseEx) {
                            mainHandler.post(() -> {
                                listener.onError(getString(R.string.err_parse, parseEx.getMessage()));
                                Notifier.notifyBalance(MainActivity.this, "解析失败", provider.name + " 返回数据无法解析");
                            });
                        }
                        break;
                    } else if (responseCode == 401) {
                        mainHandler.post(() -> {
                            listener.onError(getString(R.string.err_key_invalid));
                            Notifier.notifyBalance(MainActivity.this, "Key 失效", provider.name + " 的 API 密钥无效，请检查");
                        });
                        break;
                    } else if (responseCode == 429) {
                        if (attempt < retryCount) { attempt++; sleepQuiet(1500); continue; }
                        mainHandler.post(() -> listener.onError(getString(R.string.err_too_frequent)));
                        break;
                    } else {
                        BufferedReader errorReader = new BufferedReader(
                                new InputStreamReader(conn.getErrorStream(), "UTF-8"));
                        StringBuilder errSb = new StringBuilder();
                        String errLine;
                        while ((errLine = errorReader.readLine()) != null) {
                            errSb.append(errLine);
                        }
                        errorReader.close();
                        final String body = errSb.toString();
                        if (attempt < retryCount) { attempt++; sleepQuiet(1000); continue; }
                        mainHandler.post(() -> listener.onError(getString(R.string.err_network) + " (" + responseCode + "): " + body));
                        break;
                    }
                } catch (java.net.SocketTimeoutException e) {
                    if (attempt < retryCount) { attempt++; sleepQuiet(1000); continue; }
                    mainHandler.post(() -> listener.onError(getString(R.string.err_timeout)));
                    break;
                } catch (java.net.UnknownHostException e) {
                    mainHandler.post(() -> listener.onError(getString(R.string.err_no_network)));
                    break;
                } catch (Exception e) {
                    if (attempt < retryCount) { attempt++; sleepQuiet(1000); continue; }
                    mainHandler.post(() -> listener.onError(getString(R.string.err_network, e.getMessage())));
                    break;
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }
        }).start();
    }

    /** 关闭 TLS 证书校验（兼容自签证书，不推荐）。 */
    private void disableTlsVerify(HttpURLConnection conn) {
        try {
            javax.net.ssl.TrustManager[] trustAll = new javax.net.ssl.TrustManager[]{
                new javax.net.ssl.X509TrustManager() {
                    @Override public void checkClientTrusted(java.security.cert.X509Certificate[] c, String a) {}
                    @Override public void checkServerTrusted(java.security.cert.X509Certificate[] c, String a) {}
                    @Override public java.security.cert.X509Certificate[] getAcceptedIssuers() { return new java.security.cert.X509Certificate[0]; }
                }
            };
            javax.net.ssl.SSLContext sc = javax.net.ssl.SSLContext.getInstance("TLS");
            sc.init(null, trustAll, new java.security.SecureRandom());
            if (conn instanceof javax.net.ssl.HttpsURLConnection) {
                ((javax.net.ssl.HttpsURLConnection) conn).setSSLSocketFactory(sc.getSocketFactory());
                ((javax.net.ssl.HttpsURLConnection) conn).setHostnameVerifier((h, s) -> true);
            }
        } catch (Exception ignored) {
        }
    }

    private static void sleepQuiet(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) { }
    }

    public interface OnBalanceFetchListener {
        void onSuccess(int providerId, ProviderConfig.BalanceResult result);
        void onError(String errorMessage);
    }
}