# APIBalance

多服务商 API 余额查询安卓工具（DeepSeek / Kimi / 智谱GLM）。

## 功能
- 多服务商余额查询，密钥加密本地存储
- 余额提醒 / 定时刷新 / 通知栏常驻
- 指纹密码锁 / 隐藏余额 / 隐私开关
- 历史记录 / 趋势图 / 月度统计
- 主题中心（默认 / 复古2000 / Code CLI + 随心选色）
- 自定义背景 / 字体大小 / 网络代理 / TLS开关 / Token估算
- 桌面小组件 / 峰谷价趣味卡片

## 开源协议
本项目基于 GNU Affero General Public License v3.0 开源。
项目地址: https://github.com/RXHrxh520/APIBalance
交流群: 235492286
