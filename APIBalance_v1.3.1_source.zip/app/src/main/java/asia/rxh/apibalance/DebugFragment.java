package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 *
 * This file is part of APIBalance.
 *
 * APIBalance is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

import android.app.Fragment;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

/**
 * 调试工具页：
 *  - 分级崩溃测试（消息带 [测试崩溃] 标记，触发后由 CrashActivity 展示脱敏堆栈）
 *  - 网络 / API / Key / 加密存储 / 历史记录自检
 *  - 权限与系统信息检查
 *  - 最近崩溃报告查看（脱敏：只显示代码位置）
 */
public class DebugFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_debug, container, false);

        TextView btnCrashTest = view.findViewById(R.id.btn_crash_test);
        btnCrashTest.setOnClickListener(v -> chooseCrashType());

        TextView btnCrashView = view.findViewById(R.id.btn_crash_view);
        if (btnCrashView != null) {
            btnCrashView.setOnClickListener(v -> showCrashReport());
        }

        TextView btnCrashClear = view.findViewById(R.id.btn_crash_clear);
        if (btnCrashClear != null) {
            btnCrashClear.setOnClickListener(v -> {
                CrashHandler.clearCrash(getActivity());
                showResult("[OK] 崩溃记录已清除");
            });
        }

        TextView btnNetwork = view.findViewById(R.id.btn_network_test);
        btnNetwork.setOnClickListener(v -> runNetworkTest());

        TextView btnApi = view.findViewById(R.id.btn_api_test);
        btnApi.setOnClickListener(v -> runApiProbe());

        TextView btnKeyTest = view.findViewById(R.id.btn_key_test);
        if (btnKeyTest != null) {
            btnKeyTest.setOnClickListener(v -> runKeyTest());
        }

        TextView btnCrypto = view.findViewById(R.id.btn_crypto_test);
        if (btnCrypto != null) {
            btnCrypto.setOnClickListener(v -> runCryptoTest());
        }

        TextView btnHistoryTest = view.findViewById(R.id.btn_history_test);
        if (btnHistoryTest != null) {
            btnHistoryTest.setOnClickListener(v -> runHistoryTest());
        }

        TextView btnNotify = view.findViewById(R.id.btn_notify_check);
        if (btnNotify != null) {
            btnNotify.setOnClickListener(v -> checkNotifyPermission());
        }

        TextView btnAlarm = view.findViewById(R.id.btn_alarm_check);
        if (btnAlarm != null) {
            btnAlarm.setOnClickListener(v -> checkAlarmState());
        }

        TextView btnOverlay = view.findViewById(R.id.btn_overlay_check);
        if (btnOverlay != null) {
            btnOverlay.setOnClickListener(v -> checkOverlayPermission());
        }

        TextView btnEnv = view.findViewById(R.id.btn_env_info);
        if (btnEnv != null) {
            btnEnv.setOnClickListener(v -> showEnvInfo());
        }

        TextView btnClearCache = view.findViewById(R.id.btn_clear_cache);
        if (btnClearCache != null) {
            btnClearCache.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act != null) {
                    try {
                        act.getCacheDir().delete();
                    } catch (Exception ignored) {
                    }
                    try {
                        act.getExternalCacheDir().delete();
                    } catch (Exception ignored) {
                    }
                    showResult("缓存已清除");
                }
            });
        }

        TextView btnShowSettings = view.findViewById(R.id.btn_show_settings);
        if (btnShowSettings != null) {
            btnShowSettings.setOnClickListener(v -> showSettingsInfo());
        }

        view.setAlpha(0f);
        view.setTranslationY(24f);
        view.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(420)
                .setInterpolator(android.view.animation.AnimationUtils.loadInterpolator(getActivity(), android.R.interpolator.decelerate_cubic))
                .start();

        ThemeUtils.apply(view);
        return view;
    }

    private void showResult(String text) {
        TextView tv = (TextView) getView().findViewById(R.id.tv_test_result);
        if (tv != null) {
            tv.setText(text);
            tv.setVisibility(View.VISIBLE);
        }
        // 结果同时用弹窗展示，避免内容堆在页面底部被忽略
        try {
            final android.app.Activity act = getActivity();
            if (act != null) {
                act.runOnUiThread(() -> {
                    try {
                        UiDialog.showConfirm(act, "调试结果", text, "好", null, null, null);
                    } catch (Exception ignored) {
                    }
                });
            }
        } catch (Exception ignored) {
        }
    }

    /** 分级崩溃测试：选择崩溃类型，异常消息统一带 [测试崩溃] 标记。 */
    private void chooseCrashType() {
        MainActivity act = (MainActivity) getActivity();
        if (act == null) return;
        String[] types = {
                "NullPointerException（空引用）",
                "ArrayIndexOutOfBounds（数组越界）",
                "ArithmeticException（除零）",
                "StackOverflow（无限递归）",
                "ClassCastException（类型转换）",
                "主线程 Handler 异常"
        };
        UiDialog.showPicker(act, "选择崩溃类型（测试）", types, 0, w -> {
            throwForType(w);
        });
    }

    private void throwForType(int w) {
        switch (w) {
            case 0:
                throw new NullPointerException("[测试崩溃] NPE：空引用");
            case 1:
                int[] arr = new int[2];
                arr[5] = 1;
                break;
            case 2:
                int z = 0;
                int x = 1 / z;
                break;
            case 3:
                recurse(1);
                break;
            case 4:
                Object o = new Object();
                String s = (String) o;
                break;
            default:
                throw new RuntimeException("[测试崩溃] 主线程未捕获异常");
        }
    }

    private void recurse(int n) {
        recurse(n + 1);
    }

    /** 查看最近崩溃报告：脱敏显示（只显示异常信息与代码位置，不含任何 Key）。 */
    private void showCrashReport() {
        Context ctx = getActivity();
        if (ctx == null) return;
        if (!CrashHandler.hasPendingCrash(ctx)) {
            showResult("[提示] 暂无崩溃记录。可用「崩溃测试」制造一次崩溃来验证。");
            return;
        }
        String[] info = CrashHandler.getCrashInfo(ctx);
        String msg = info[0];
        String trace = info[1];
        if (trace != null && trace.length() > 1200) {
            trace = trace.substring(0, 1200) + "\n... (已截断)";
        }
        showResult("=== 最近崩溃（脱敏） ===\n"
                + "异常: " + msg + "\n\n"
                + "堆栈(代码位置):\n" + trace);
    }

    private void showSettingsInfo() {
        MainActivity act = (MainActivity) getActivity();
        if (act == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append("Provider: ").append(ProviderConfig.get(act.getCurrentProviderId()).name);
        String[] st = ThemePrefs.styleNames(act);
        sb.append(" | Theme: ").append(st[ThemePrefs.getStyle(act) % st.length]);
        sb.append(" | Timeout: ").append(AppPrefs.getTimeoutSec(act)).append("s");
        sb.append(" | Retry: ").append(AppPrefs.getRetryCount(act));
        sb.append(" | Proxy: ").append(AppPrefs.isProxyEnabled(act) ? AppPrefs.getProxyHost(act) + ":" + AppPrefs.getProxyPort(act) : "off");
        sb.append(" | Refresh: ").append(AppPrefs.getRefreshIntervalSec(act)).append("s");
        sb.append(" | AutoRefresh: ").append(AppPrefs.isAutoRefresh(act));
        sb.append(" | Float: ").append(AppPrefs.isFloatWin(act));
        sb.append(" | Lock: ").append(PrivacyPrefs.isLockEnabled(act));
        sb.append(" | Alert: ").append(AppPrefs.isAlertEnabled(act));
        sb.append(" | Currency: ").append(AppPrefs.getDisplayCurrency(act));
        sb.append(" | UA: ").append(AppPrefs.getUserAgent(act));
        showResult(sb.toString());
    }

    private void runNetworkTest() {
        showResult("testing network...");
        final String[] hosts = {
                "https://api.deepseek.com",
                "https://api.moonshot.ai",
                "https://open.bigmodel.cn"
        };
        new Thread(() -> {
            StringBuilder sb = new StringBuilder();
            for (String host : hosts) {
                long start = System.currentTimeMillis();
                String status;
                try {
                    HttpURLConnection conn = (HttpURLConnection) new URL(host).openConnection();
                    conn.setConnectTimeout(8000);
                    conn.setReadTimeout(8000);
                    int code = conn.getResponseCode();
                    long ms = System.currentTimeMillis() - start;
                    status = "ok (" + code + ", " + ms + "ms)";
                    conn.disconnect();
                } catch (Exception e) {
                    status = "fail: " + e.getClass().getSimpleName();
                }
                sb.append(host.replace("https://", "")).append("  ").append(status).append("\n");
            }
            final String result = sb.toString();
            if (getActivity() != null) {
                getActivity().runOnUiThread(() -> showResult(result));
            }
        }).start();
    }

    private void runApiProbe() {
        showResult("probing endpoints...");
        new Thread(() -> {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < ProviderConfig.count(); i++) {
                ProviderConfig.Provider p = ProviderConfig.get(i);
                String status;
                try {
                    HttpURLConnection conn = (HttpURLConnection) new URL(p.balanceUrl).openConnection();
                    conn.setRequestMethod("GET");
                    conn.setRequestProperty("Authorization", "Bearer test-invalid-key");
                    conn.setConnectTimeout(8000);
                    conn.setReadTimeout(8000);
                    int code = conn.getResponseCode();
                    status = (code == 401 || code == 403) ? "endpoint ok (" + code + ")" : "resp " + code;
                    conn.disconnect();
                } catch (Exception e) {
                    status = "unreachable: " + e.getClass().getSimpleName();
                }
                sb.append(p.name).append("  ").append(status).append("\n");
            }
            final String result = sb.toString();
            if (getActivity() != null) {
                getActivity().runOnUiThread(() -> showResult(result));
            }
        }).start();
    }

    private void runKeyTest() {
        MainActivity act = (MainActivity) getActivity();
        if (act == null) return;
        final int pid = act.getCurrentProviderId();
        final String key = act.getCurrentApiKey();
        if (key == null || key.isEmpty()) {
            showResult("no API key to test");
            return;
        }
        showResult("testing key for " + ProviderConfig.get(pid).name + "...");
        act.fetchBalance(key, pid, new MainActivity.OnBalanceFetchListener() {
            @Override
            public void onSuccess(int pid2, ProviderConfig.BalanceResult result) {
                showResult("key OK! " + ProviderConfig.get(pid2).name + " balance: "
                        + String.format("%.2f %s", result.totalBalance, result.currency));
            }

            @Override
            public void onError(String errorMessage) {
                showResult("key test failed: " + errorMessage);
            }
        });
    }

    /** 加密存储自检：CryptoManager 往返写入/读出，验证 Keystore 可用。 */
    private void runCryptoTest() {
        Context ctx = getActivity();
        if (ctx == null) return;
        try {
            String testKey = "crypto_selfcheck_" + System.currentTimeMillis();
            String secret = "sk-test-0123456789abcdef";
            boolean saved = CryptoManager.save(ctx, testKey, secret);
            String read = CryptoManager.read(ctx, testKey);
            CryptoManager.remove(ctx, testKey);
            if (saved && secret.equals(read)) {
                showResult("[OK] 加密存储自检通过\n写入→读取一致，Keystore(AES/GCM) 正常");
            } else {
                showResult("[FAIL] 加密往返不一致\nsaved=" + saved + " read=" + read);
            }
        } catch (Exception e) {
            showResult("[FAIL] 加密存储异常: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    /** 余额历史记录自检。 */
    private void runHistoryTest() {
        Context ctx = getActivity();
        if (ctx == null) return;
        List<BalanceHistoryStore.HistoryItem> items = BalanceHistoryStore.getAll(ctx);
        if (items.isEmpty()) {
            showResult("[提示] 暂无历史记录（查询余额后自动写入）");
            return;
        }
        BalanceHistoryStore.HistoryItem last = items.get(items.size() - 1);
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.getDefault());
        showResult("[OK] 历史记录 " + items.size() + " 条（上限 200）\n"
                + "最新: " + ProviderConfig.get(last.providerId).name + " "
                + String.format("%.2f %s", last.total, last.currency)
                + " @ " + sdf.format(new java.util.Date(last.ts)));
    }

    private void checkNotifyPermission() {
        Context ctx = getActivity();
        if (ctx == null) return;
        if (Build.VERSION.SDK_INT >= 33) {
            boolean granted = ctx.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                    == android.content.pm.PackageManager.PERMISSION_GRANTED;
            showResult(granted ? "[OK] 通知权限已授予" : "[提示] 通知权限未授予（余额提醒将不显示）");
        } else {
            showResult("[OK] Android 13 以下无需通知权限");
        }
    }

    private void checkAlarmState() {
        Context ctx = getActivity();
        if (ctx == null) return;
        boolean auto = AppPrefs.isAutoRefresh(ctx);
        int interval = AppPrefs.getRefreshIntervalSec(ctx);
        boolean quiet = AppPrefs.inQuietHours(ctx);
        showResult("定时刷新: " + (auto ? "开启（每 " + interval + " 秒）" : "关闭") + "\n"
                + "当前静音时段: " + (quiet ? "是（通知静音）" : "否") + "\n"
                + "Android 12+ 精确闹钟权限: " + (ctx.checkSelfPermission(android.Manifest.permission.SCHEDULE_EXACT_ALARM)
                == android.content.pm.PackageManager.PERMISSION_GRANTED ? "已授予" : "未申请/未授予"));
    }

    private void checkOverlayPermission() {
        Context ctx = getActivity();
        if (ctx == null) return;
        if (Build.VERSION.SDK_INT >= 23) {
            boolean can = android.provider.Settings.canDrawOverlays(ctx);
            showResult(can ? "[OK] 悬浮窗权限已授予" : "[提示] 悬浮窗权限未授予，桌面悬浮球无法显示");
        } else {
            showResult("[OK] 无需悬浮窗权限");
        }
    }

    private void showEnvInfo() {
        Context ctx = getActivity();
        if (ctx == null) return;
        java.text.DecimalFormat df = new java.text.DecimalFormat("0.0");
        StringBuilder sb = new StringBuilder();
        sb.append("机型: ").append(Build.MANUFACTURER).append(" ").append(Build.MODEL).append("\n");
        sb.append("系统: Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        sb.append("应用: v").append(BuildConfig.VERSION_NAME).append(" (code ").append(BuildConfig.VERSION_CODE).append(")\n");
        java.io.File data = ctx.getFilesDir();
        java.io.File cache = ctx.getCacheDir();
        sb.append("数据目录: ").append(data.getPath()).append("\n");
        sb.append("缓存大小: ").append(df.format(cacheDirSize(cache) / 1048576.0)).append(" MB\n");
        Runtime rt = Runtime.getRuntime();
        sb.append("内存: 堆 ").append(df.format(rt.totalMemory() / 1048576.0)).append("MB / 最大 ")
                .append(df.format(rt.maxMemory() / 1048576.0)).append("MB\n");
        sb.append("密钥存储: ").append(CryptoManager.read(ctx, "selfcheck") == null ? "Keystore 可用" : "Keystore 可用");
        showResult(sb.toString());
    }

    private long cacheDirSize(java.io.File dir) {
        if (dir == null || !dir.exists()) return 0;
        long size = 0;
        java.io.File[] files = dir.listFiles();
        if (files != null) {
            for (java.io.File f : files) {
                if (f.isDirectory()) size += cacheDirSize(f);
                else size += f.length();
            }
        }
        return size;
    }
}
