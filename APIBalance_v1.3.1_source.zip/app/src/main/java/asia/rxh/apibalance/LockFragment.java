package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 * ... (AGPLv3, see MainActivity)
 */

import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.Executor;

public class LockFragment extends Fragment {

    private EditText etPassword;
    private TextView tvUnlock;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_lock, container, false);

        etPassword = view.findViewById(R.id.et_password);
        tvUnlock = view.findViewById(R.id.btn_unlock);

        // 优先尝试指纹
        tryBiometric();

        tvUnlock.setOnClickListener(v -> {
            String pw = etPassword.getText().toString().trim();
            if (!PrivacyPrefs.hasPassword(getActivity())) {
                // 首次设置密码
                if (pw.length() < 4) {
                    Toast.makeText(getActivity(), getString(R.string.j_144), Toast.LENGTH_SHORT).show();
                    return;
                }
                PrivacyPrefs.setPassword(getActivity(), pw);
                Toast.makeText(getActivity(), getString(R.string.j_145), Toast.LENGTH_SHORT).show();
                unlock();
            } else {
                if (PrivacyPrefs.checkPassword(getActivity(), pw)) {
                    unlock();
                } else {
                    Toast.makeText(getActivity(), getString(R.string.j_146), Toast.LENGTH_SHORT).show();
                    etPassword.setText("");
                }
            }
        });

        ThemeUtils.apply(view);
        return view;
    }

    private void tryBiometric() {
        final android.app.Activity act = getActivity();
        if (act == null) return;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return;
        try {
            // FingerprintManager（minSdk 26 可用）。BiometricPrompt 在本工具链
            // 的 stub android.jar 中无公开构造器，故不采用。
            android.hardware.fingerprint.FingerprintManager fm =
                    act.getSystemService(android.hardware.fingerprint.FingerprintManager.class);
            if (fm == null || !fm.isHardwareDetected() || !fm.hasEnrolledFingerprints()) {
                return; // 无指纹硬件/未录入：静默等密码
            }
            android.hardware.fingerprint.FingerprintManager.AuthenticationCallback cb =
                    new android.hardware.fingerprint.FingerprintManager.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationSucceeded(android.hardware.fingerprint.FingerprintManager.AuthenticationResult result) {
                            if (getActivity() != null) {
                                getActivity().runOnUiThread(() -> unlock());
                            }
                        }
                    };
            fm.authenticate(null, null, 0, cb, null);
        } catch (SecurityException ignored) {
            // 无锁屏/厂商限制时抛 SecurityException，静默降级为密码解锁
        } catch (Exception ignored) {
        }
    }

    private void unlock() {
        MainActivity act = (MainActivity) getActivity();
        if (act != null) act.onLockPassed();
    }
}