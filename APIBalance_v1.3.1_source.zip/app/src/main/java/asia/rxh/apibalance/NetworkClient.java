package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 *
 * This file is part of APIBalance.
 *
 * APIBalance is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * APIBalance is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import android.content.Context;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.SocketTimeoutException;
import java.net.URL;

/**
 * 统一网络请求层：余额查询的所有请求（前台/后台定时刷新）都走这里，
 * 保证代理、超时、重试、UA 等设置行为一致。
 * TLS 证书校验恒开启，不允许关闭。
 */
public final class NetworkClient {

    private NetworkClient() {
    }

    /** 服务端返回非 200 时抛出，code 为 HTTP 状态码，body 为响应体（已截断）。 */
    public static final class HttpException extends Exception {
        public final int code;
        public final String body;

        HttpException(int code, String body) {
            super("HTTP " + code);
            this.code = code;
            this.body = body;
        }
    }

    /** 响应 JSON 无法解析时抛出。 */
    public static final class ParseException extends Exception {
        public ParseException(String msg) {
            super(msg);
        }
    }

    /**
     * 同步查询余额。按 AppPrefs 应用超时/重试/代理/UA 设置。
     * 401 / 429 / 其他 HTTP 错误抛 {@link HttpException}；
     * JSON 解析失败抛 {@link ParseException}；
     * 网络异常抛 SocketTimeoutException / UnknownHostException 等。
     */
    public static ProviderConfig.BalanceResult fetch(Context ctx, int providerId, String apiKey) throws Exception {
        ProviderConfig.Provider provider = ProviderConfig.get(providerId);
        int timeoutSec = AppPrefs.getTimeoutSec(ctx);
        int retryCount = AppPrefs.getRetryCount(ctx);
        int attempt = 0;

        while (true) {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(provider.balanceUrl);
                if (AppPrefs.isProxyEnabled(ctx)) {
                    Proxy proxy = new Proxy(Proxy.Type.HTTP,
                            new InetSocketAddress(AppPrefs.getProxyHost(ctx), AppPrefs.getProxyPort(ctx)));
                    conn = (HttpURLConnection) url.openConnection(proxy);
                } else {
                    conn = (HttpURLConnection) url.openConnection();
                }
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Authorization", "Bearer " + apiKey);
                conn.setRequestProperty("Accept", "application/json");
                conn.setRequestProperty("User-Agent", AppPrefs.getUserAgent(ctx));
                conn.setConnectTimeout(timeoutSec * 1000);
                conn.setReadTimeout(timeoutSec * 1000);

                int responseCode = conn.getResponseCode();
                if (responseCode == 200) {
                    String json = readStream(conn.getInputStream());
                    try {
                        return provider.parse(json);
                    } catch (Exception parseEx) {
                        throw new ParseException(parseEx.getMessage() == null
                                ? "unknown" : parseEx.getMessage());
                    }
                } else if (responseCode == 401) {
                    throw new HttpException(401, null);
                } else if (responseCode == 429) {
                    if (attempt < retryCount) {
                        attempt++;
                        sleepQuiet(1500);
                        continue;
                    }
                    throw new HttpException(429, null);
                } else {
                    String body = readStream(conn.getErrorStream());
                    if (attempt < retryCount) {
                        attempt++;
                        sleepQuiet(1000);
                        continue;
                    }
                    throw new HttpException(responseCode, truncate(body, 200));
                }
            } catch (SocketTimeoutException e) {
                if (attempt < retryCount) {
                    attempt++;
                    sleepQuiet(1000);
                    continue;
                }
                throw e;
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
    }

    private static String readStream(InputStream is) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();
        return sb.toString();
    }

    private static String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }

    private static void sleepQuiet(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
        }
    }
}
