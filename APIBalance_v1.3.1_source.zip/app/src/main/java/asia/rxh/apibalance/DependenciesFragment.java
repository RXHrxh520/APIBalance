package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 *
 * This file is part of APIBalance.
 *
 * APIBalance is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * 第三方依赖统计页：如实列出本项目使用的所有技术栈/依赖/许可。
 */
public class DependenciesFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dependencies, container, false);

        ImageViewBtnBack(view);

        StringBuilder sb = new StringBuilder();
        sb.append("── 版本信息 ──\n");
        sb.append("• v" + BuildConfig.VERSION_NAME + " (code " + BuildConfig.VERSION_CODE + ")\n\n");
        sb.append("── 编程语言 ──\n");
        sb.append("• Java 8 语法（100% 应用代码，无 Kotlin）\n\n");
        sb.append("── 运行时 / 平台 ──\n");
        sb.append("• Android API 34（minSdk 26 / targetSdk 34 / compileSdk 34）\n");
        sb.append("• Android Framework 系统库：\n");
        sb.append("  - android.security.keystore（AES/GCM 密钥存储）\n");
        sb.append("  - org.json（内置 JSON）\n");
        sb.append("  - android.widget.*（原生控件，无 AndroidX）\n");
        sb.append("  - MediaStore / ShortcutManager / AlarmManager / WindowManager\n");
        sb.append("  - HttpURLConnection（网络，无 OkHttp）\n\n");
        sb.append("── 构建工具链 ──\n");
        sb.append("• JDK 17 (Temurin)\n");
        sb.append("• Gradle 7.5\n");
        sb.append("• Android Gradle Plugin 7.4.2\n");
        sb.append("• aapt2 2.19（arm64 原生）\n");
        sb.append("• buildTools 34.0.0\n\n");
        sb.append("── 第三方运行时依赖 ──\n");
        sb.append("• 无（零第三方运行时库）\n");
        sb.append("• 图表/分享图：Canvas 自绘\n");
        sb.append("• 图标：Material Design Icons（Apache 2.0）\n\n");
        sb.append("── 网络服务（第三方） ──\n");
        sb.append("• DeepSeek 官方余额 API\n");
        sb.append("• Moonshot (Kimi) 官方余额 API\n");
        sb.append("• 智谱 BigModel 官方余额 API\n");
        sb.append("• OpenAI 官方 Billing API\n");
        sb.append("• Anthropic 官方 Usage API\n");
        sb.append("• GitHub API（版本检查）\n");
        sb.append("• 用户自定义汇率 JSON 地址（可选）\n\n");
        sb.append("── 许可 ──\n");
        sb.append("• GNU AGPL v3.0（本应用开源协议）\n");
        sb.append("• 服务商 API 的使用遵守各服务商服务条款\n");

        TextView tv = view.findViewById(R.id.tv_deps);
        tv.setText(sb.toString());

        ThemeUtils.apply(view);
        return view;
    }

    private void ImageViewBtnBack(final View view) {
        view.findViewById(R.id.btn_back).setOnClickListener(v -> {
            if (getActivity() != null) getFragmentManager().popBackStack();
        });
    }
}
