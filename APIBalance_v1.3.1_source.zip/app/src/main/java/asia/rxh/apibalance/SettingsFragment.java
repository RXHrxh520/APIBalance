package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 * ... (AGPLv3, see MainActivity)
 */

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

public class SettingsFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        ImageView btnBack = view.findViewById(R.id.btn_back);
        View btnChangeKey = view.findViewById(R.id.btn_change_key);
        View btnSwitchProvider = view.findViewById(R.id.btn_switch_provider);
        View btnAccounts = view.findViewById(R.id.btn_accounts);
        View btnHistory = view.findViewById(R.id.btn_history);
        View btnTheme = view.findViewById(R.id.btn_theme);
        View btnTimeout = view.findViewById(R.id.btn_timeout);
        View btnCurrency = view.findViewById(R.id.btn_currency);
        View btnClearData = view.findViewById(R.id.btn_clear_data);
        View btnTokenEst = view.findViewById(R.id.btn_token_est);
        View btnAdvancedNet = view.findViewById(R.id.btn_advanced_net);
        View btnFontSize = view.findViewById(R.id.btn_font_size);
        View btnCustomBg = view.findViewById(R.id.btn_custom_bg);
        TextView tvFontSize = view.findViewById(R.id.tv_font_size);
        TextView tvBgDesc = view.findViewById(R.id.tv_bg_desc);
        View btnProxy = view.findViewById(R.id.btn_proxy);
        Switch swProxy = view.findViewById(R.id.sw_proxy);
        TextView tvProxyDesc = view.findViewById(R.id.tv_proxy_desc);
        TextView tvTimeoutDesc = view.findViewById(R.id.tv_timeout_desc);
        TextView tvCurrencyDesc = view.findViewById(R.id.tv_currency_desc);
        Switch swLock = view.findViewById(R.id.sw_lock);
        Switch swHideBalance = view.findViewById(R.id.sw_hide_balance);
        Switch swNoScreenshot = view.findViewById(R.id.sw_no_screenshot);
        Switch swNoNotify = view.findViewById(R.id.sw_no_notify);
        Switch swFloat = view.findViewById(R.id.sw_float);
        View rowFloat = view.findViewById(R.id.row_float);
        Switch swAlert = view.findViewById(R.id.sw_alert);
        Switch swAutoRefresh = view.findViewById(R.id.sw_auto_refresh);
        Switch swQuiet = view.findViewById(R.id.sw_quiet);
        Switch swSticky = view.findViewById(R.id.sw_sticky);
        TextView tvQuietDesc = view.findViewById(R.id.tv_quiet_desc);
        View rowQuiet = view.findViewById(R.id.row_quiet);
        View rowSticky = view.findViewById(R.id.row_sticky);
        TextView tvAlertDesc = view.findViewById(R.id.tv_alert_desc);
        View rowAlert = view.findViewById(R.id.row_alert);
        View rowAutoRefresh = view.findViewById(R.id.row_auto_refresh);
        View rowLock = view.findViewById(R.id.row_lock);
        View rowHideBalance = view.findViewById(R.id.row_hide_balance);
        View rowNoScreenshot = view.findViewById(R.id.row_no_screenshot);
        View rowNoNotify = view.findViewById(R.id.row_no_notify);
        TextView tvThemeMode = view.findViewById(R.id.tv_theme_mode);
        View btnLang = view.findViewById(R.id.btn_lang);
        TextView tvLangDesc = view.findViewById(R.id.tv_lang_desc);
        View rowAutoDark = view.findViewById(R.id.row_auto_dark);
        Switch swAutoDark = view.findViewById(R.id.sw_auto_dark);
        TextView tvAutoDarkDesc = view.findViewById(R.id.tv_auto_dark_desc);
        View rowAutoLock = view.findViewById(R.id.row_auto_lock);
        TextView tvAutoLockDesc = view.findViewById(R.id.tv_auto_lock_desc);
        View btnAbout = view.findViewById(R.id.btn_about);
        View btnDeps = view.findViewById(R.id.btn_deps);
        View btnUpdate = view.findViewById(R.id.btn_update);
        View btnDebug = view.findViewById(R.id.btn_debug);
        TextView tvCurrentProvider = view.findViewById(R.id.tv_current_provider);

        MainActivity activity = (MainActivity) getActivity();
        if (activity != null) {
            if (activity.isDebugEnabled()) {
                btnDebug.setVisibility(View.VISIBLE);
            }
            if (tvCurrentProvider != null) {
                tvCurrentProvider.setText(getString(R.string.j_001) + ProviderConfig.get(activity.getCurrentProviderId()).name);
            }
            if (tvTimeoutDesc != null) {
                tvTimeoutDesc.setText(getString(R.string.j_002) + AppPrefs.getTimeoutSec(getActivity()) + getString(R.string.j_003) + AppPrefs.getRetryCount(getActivity()) + getString(R.string.j_004));
            }
            if (tvCurrencyDesc != null) {
                int cm = AppPrefs.getDisplayCurrency(getActivity());
                tvCurrencyDesc.setText(cm == 1 ? "CNY" : cm == 2 ? "USD" : getString(R.string.j_005));
            }
        }

        btnBack.setOnClickListener(v -> {
            // 设置是底部 Tab：返回切回余额/登录页
            MainActivity act = (MainActivity) getActivity();
            if (act != null) act.switchTab(0);
        });

        // 提醒/刷新
        if (swAlert != null) {
            swAlert.setChecked(AppPrefs.isAlertEnabled(getActivity()));
            swAlert.setOnCheckedChangeListener((b, isChecked) -> AppPrefs.setAlertEnabled(getActivity(), isChecked));
            if (rowAlert != null) {
                rowAlert.setOnClickListener(v -> {
                    MainActivity act = (MainActivity) getActivity();
                    if (act == null) return;
                    final String[] opts = {"5", "10", "20", "50", "100"};
                    int sel = 1;
                    double cur = AppPrefs.getAlertThreshold(act);
                    for (int i = 0; i < opts.length; i++) {
                        if ((int) cur == Integer.parseInt(opts[i])) { sel = i; break; }
                    }
                    UiDialog.showPickerWithDesc(act, getString(R.string.j_006),
                            getString(R.string.j_007), opts, sel, w -> {
                        AppPrefs.setAlertThreshold(act, Integer.parseInt(opts[w]));
                        if (tvAlertDesc != null) tvAlertDesc.setText(getString(R.string.j_008) + opts[w]);
                    });
                });
            }
        }
        if (swAutoRefresh != null) {
            swAutoRefresh.setChecked(AppPrefs.isAutoRefresh(getActivity()));
            swAutoRefresh.setOnCheckedChangeListener((b, isChecked) -> {
                AppPrefs.setAutoRefresh(getActivity(), isChecked);
                MainActivity act = (MainActivity) getActivity();
                if (act != null) act.scheduleAutoRefresh(isChecked);
            });
        }

        // 通知增强
        if (swQuiet != null) {
            swQuiet.setChecked(AppPrefs.isQuietEnabled(getActivity()));
            if (tvQuietDesc != null) {
                tvQuietDesc.setText(AppPrefs.getQuietStart(getActivity()) + ":00 - "
                        + AppPrefs.getQuietEnd(getActivity()) + getString(R.string.j_009));
            }
            swQuiet.setOnCheckedChangeListener((b, isChecked) -> AppPrefs.setQuietEnabled(getActivity(), isChecked));
            if (rowQuiet != null) {
                rowQuiet.setOnClickListener(v -> {
                    MainActivity act = (MainActivity) getActivity();
                    if (act == null) return;
                    String[] hours = new String[24];
                    for (int i = 0; i < 24; i++) hours[i] = i + ":00";
                    UiDialog.showPickerWithDesc(act, getString(R.string.j_010),
                            getString(R.string.j_011), hours, AppPrefs.getQuietStart(act), s -> {
                        AppPrefs.setQuietStart(act, s);
                        UiDialog.showPickerWithDesc(act, getString(R.string.j_012),
                                getString(R.string.j_011), hours, AppPrefs.getQuietEnd(act), e -> {
                            AppPrefs.setQuietEnd(act, e);
                            if (tvQuietDesc != null) {
                                tvQuietDesc.setText(s + ":00 - " + e + getString(R.string.j_009));
                            }
                        });
                    });
                });
            }
        }
        if (swSticky != null) {
            swSticky.setChecked(AppPrefs.isStickyNotify(getActivity()));
            swSticky.setOnCheckedChangeListener((b, isChecked) -> {
                AppPrefs.setStickyNotify(getActivity(), isChecked);
                MainActivity act = (MainActivity) getActivity();
                if (act != null) {
                    if (isChecked) act.showStickyNotify();
                    else Notifier.cancelSticky(act);
                }
            });
        }

        // 桌面悬浮球
        if (swFloat != null) {
            swFloat.setChecked(AppPrefs.isFloatWin(getActivity()));
            swFloat.setOnCheckedChangeListener((b, isChecked) -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                if (isChecked) {
                    if (android.os.Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.canDrawOverlays(act)) {
                        UiDialog.showConfirm(act, getString(R.string.j_013),
                                getString(R.string.j_014),
                                getString(R.string.j_015), getString(R.string.j_016),
                                () -> {
                                    try {
                                        act.startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                                android.net.Uri.parse("package:" + act.getPackageName())));
                                    } catch (Exception ignored) {
                                    }
                                }, () -> swFloat.setChecked(false));
                    } else {
                        act.startService(new Intent(act, FloatingWindowService.class));
                    }
                } else {
                    act.stopService(new Intent(act, FloatingWindowService.class));
                }
                AppPrefs.setFloatWin(act, isChecked);
            });
        }

        // 隐私开关
        if (swLock != null) {
            swLock.setChecked(PrivacyPrefs.isLockEnabled(getActivity()));
            swLock.setOnCheckedChangeListener((b, isChecked) -> PrivacyPrefs.setLockEnabled(getActivity(), isChecked));
        }
        if (swHideBalance != null) {
            swHideBalance.setChecked(PrivacyPrefs.isHideBalance(getActivity()));
            swHideBalance.setOnCheckedChangeListener((b, isChecked) -> PrivacyPrefs.setHideBalance(getActivity(), isChecked));
        }
        if (swNoScreenshot != null) {
            swNoScreenshot.setChecked(AppPrefs.noScreenshot(getActivity()));
            swNoScreenshot.setOnCheckedChangeListener((b, isChecked) -> {
                AppPrefs.setNoScreenshot(getActivity(), isChecked);
                MainActivity act = (MainActivity) getActivity();
                if (act != null) act.applyPrivacyFlags();
            });
        }
        if (swNoNotify != null) {
            swNoNotify.setChecked(AppPrefs.noNotify(getActivity()));
            swNoNotify.setOnCheckedChangeListener((b, isChecked) -> AppPrefs.setNoNotify(getActivity(), isChecked));
        }

        // 语言切换
        if (btnLang != null && tvLangDesc != null) {
            int lang0 = AppPrefs.getLanguage(getActivity());
            tvLangDesc.setText(lang0 == 1 ? getString(R.string.j_017) : lang0 == 2 ? "English"
                    : lang0 == 3 ? "繁體中文" : getString(R.string.str_026));
            btnLang.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                String[] opts = {getString(R.string.j_018), getString(R.string.j_017), "English", "繁體中文"};
                int sel = AppPrefs.getLanguage(act);
                UiDialog.showPickerWithDesc(act, getString(R.string.j_019),
                        getString(R.string.j_020), opts, sel == 0 ? 0 : sel, w -> {
                    AppPrefs.setLanguage(act, w);
                    act.recreate();
                });
            });
        }

        // 定时自动深色
        if (rowAutoDark != null && swAutoDark != null) {
            swAutoDark.setChecked(AppPrefs.isAutoDark(getActivity()));
            if (tvAutoDarkDesc != null) {
                tvAutoDarkDesc.setText(getString(R.string.auto_dark_desc));
            }
            swAutoDark.setOnCheckedChangeListener((b, isChecked) -> AppPrefs.setAutoDark(getActivity(), isChecked));
            rowAutoDark.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                String[] hours = new String[24];
                for (int i = 0; i < 24; i++) hours[i] = i + ":00";
                UiDialog.showPickerWithDesc(act, getString(R.string.auto_dark_start),
                        getString(R.string.auto_dark_desc), hours, AppPrefs.getAutoDarkStart(act), s -> {
                    AppPrefs.setAutoDarkStart(act, s);
                    UiDialog.showPickerWithDesc(act, getString(R.string.auto_dark_end),
                            getString(R.string.auto_dark_desc), hours, AppPrefs.getAutoDarkEnd(act), e -> {
                        AppPrefs.setAutoDarkEnd(act, e);
                    });
                });
            });
        }

        // 定时自动锁
        if (rowAutoLock != null && tvAutoLockDesc != null) {
            int cur = AppPrefs.getAutoLockMinutes(getActivity());
            tvAutoLockDesc.setText(cur == 0 ? getString(R.string.auto_lock_off)
                    : cur + getString(R.string.auto_lock_min));
            rowAutoLock.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                String[] opts = {getString(R.string.auto_lock_off), "1" + getString(R.string.auto_lock_min),
                        "5" + getString(R.string.auto_lock_min), "15" + getString(R.string.auto_lock_min)};
                int sel = cur == 1 ? 1 : cur == 5 ? 2 : cur == 15 ? 3 : 0;
                UiDialog.showPickerWithDesc(act, getString(R.string.auto_lock),
                        getString(R.string.auto_lock_desc), opts, sel, w -> {
                    int min = w == 1 ? 1 : w == 2 ? 5 : w == 3 ? 15 : 0;
                    AppPrefs.setAutoLockMinutes(act, min);
                    tvAutoLockDesc.setText(min == 0 ? getString(R.string.auto_lock_off)
                            : min + getString(R.string.auto_lock_min));
                });
            });
        }

        // 主题中心：明暗模式 → 风格 → 强调色 三步合一
        if (btnTheme != null && tvThemeMode != null) {
            final MainActivity act0 = (MainActivity) getActivity();
            if (act0 != null) {
                int tm0 = act0.getThemeMode();
                int style0 = ThemePrefs.getStyle(act0);
                int col0 = ThemePrefs.getColorIndex(act0);
                String[] stn = ThemePrefs.styleNames(act0);
                String[] cln = ThemePrefs.colorNames(act0);
                tvThemeMode.setText(stn[style0 % stn.length]
                        + " · " + cln[col0 % cln.length]
                        + " · " + (tm0 == 2 ? getString(R.string.j_021) : tm0 == 1 ? getString(R.string.j_022) : getString(R.string.str_026)));
            }
            btnTheme.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                String[] modes = {getString(R.string.j_018), getString(R.string.j_022), getString(R.string.j_021)};
                UiDialog.showPickerWithDesc(act, getString(R.string.j_023),
                        getString(R.string.j_024), modes, act.getThemeMode(), w1 -> {
                    UiDialog.showPickerWithDesc(act, getString(R.string.j_025),
                            getString(R.string.j_026),
                            ThemePrefs.styleNames(act), ThemePrefs.getStyle(act), w2 -> {
                        UiDialog.showPickerWithDesc(act, getString(R.string.j_027),
                                getString(R.string.j_028),
                                ThemePrefs.colorNames(act), ThemePrefs.getColorIndex(act), w3 -> {
                            ThemePrefs.setStyle(act, w2);
                            ThemePrefs.setColorIndex(act, w3);
                            act.setThemeMode(w1); // 最后统一应用并重建界面
                        });
                    });
                });
            });
        }

        // 超时/重试
        if (btnTimeout != null) {
            btnTimeout.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                final int cur = AppPrefs.getTimeoutSec(act);
                final int curRetry = AppPrefs.getRetryCount(act);
                String[] timeouts = {getString(R.string.j_029), getString(R.string.j_030), getString(R.string.j_031), getString(R.string.j_032)};
                int sel = cur == 10 ? 0 : cur == 30 ? 2 : cur == 60 ? 3 : 1;
                UiDialog.showPickerWithDesc(act, getString(R.string.j_033),
                        getString(R.string.j_034), timeouts, sel, w -> {
                    int sec = w == 0 ? 10 : w == 2 ? 30 : w == 3 ? 60 : 15;
                    AppPrefs.setTimeoutSec(act, sec);
                    if (tvTimeoutDesc != null)
                        tvTimeoutDesc.setText(getString(R.string.j_002) + sec + getString(R.string.j_003) + curRetry + getString(R.string.j_004));
                });
            });
        }

        // 多币种
        if (btnCurrency != null) {
            btnCurrency.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                String[] modes = {getString(R.string.j_005), "CNY", "USD", getString(R.string.rate_custom), getString(R.string.rate_refresh)};
                UiDialog.showPickerWithDesc(act, getString(R.string.j_035),
                        getString(R.string.rate_desc), modes, AppPrefs.getDisplayCurrency(act), w -> {
                    if (w == 3) {
                        // 自定义汇率：用户填写「汇率 JSON 地址」，App 拉取该地址并解析 {"usd_cny": 7.2}
                        UiDialog.showInputWithDesc(act, getString(R.string.rate_title),
                                getString(R.string.rate_url_desc), getString(R.string.rate_url_hint), AppPrefs.getRateUrl(act), url -> {
                            if (url == null || url.trim().isEmpty()) {
                                AppPrefs.setRateUrl(act, null);
                                android.widget.Toast.makeText(act, getString(R.string.rate_cleared), android.widget.Toast.LENGTH_SHORT).show();
                                return;
                            }
                            AppPrefs.setRateUrl(act, url.trim());
                            android.widget.Toast.makeText(act, getString(R.string.rate_fetching), android.widget.Toast.LENGTH_SHORT).show();
                            new Thread(() -> {
                                final double rate = FxRateFetcher.fetch(act);
                                act.runOnUiThread(() -> {
                                    if (rate > 0) {
                                        android.widget.Toast.makeText(act,
                                                getString(R.string.rate_saved) + rate, android.widget.Toast.LENGTH_SHORT).show();
                                    } else {
                                        android.widget.Toast.makeText(act,
                                                getString(R.string.rate_invalid), android.widget.Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }).start();
                        });
                        return;
                    }
                    if (w == 4) {
                        // 重新拉取已保存的汇率地址
                        if (AppPrefs.getRateUrl(act) == null) {
                            android.widget.Toast.makeText(act, getString(R.string.rate_no_url), android.widget.Toast.LENGTH_SHORT).show();
                            return;
                        }
                        android.widget.Toast.makeText(act, getString(R.string.rate_fetching), android.widget.Toast.LENGTH_SHORT).show();
                        new Thread(() -> {
                            final double rate = FxRateFetcher.fetch(act);
                            act.runOnUiThread(() -> {
                                if (rate > 0) {
                                    android.widget.Toast.makeText(act,
                                            getString(R.string.rate_saved) + rate, android.widget.Toast.LENGTH_SHORT).show();
                                } else {
                                    android.widget.Toast.makeText(act,
                                            getString(R.string.rate_invalid), android.widget.Toast.LENGTH_SHORT).show();
                                }
                            });
                        }).start();
                        return;
                    }
                    AppPrefs.setDisplayCurrency(act, w);
                    if (tvCurrencyDesc != null)
                        tvCurrencyDesc.setText(w == 1 ? "CNY" : w == 2 ? "USD" : getString(R.string.j_005));
                });
            });
        }

        // 网络代理
        if (btnProxy != null && swProxy != null) {
            swProxy.setChecked(AppPrefs.isProxyEnabled(getActivity()));
            if (tvProxyDesc != null) {
                tvProxyDesc.setText((AppPrefs.isProxyEnabled(getActivity()) ? getString(R.string.j_037) : getString(R.string.j_038))
                        + " · " + AppPrefs.getProxyHost(getActivity()) + ":" + AppPrefs.getProxyPort(getActivity()));
            }
            swProxy.setOnCheckedChangeListener((b, isChecked) -> {
                AppPrefs.setProxyEnabled(getActivity(), isChecked);
                if (tvProxyDesc != null) {
                    tvProxyDesc.setText((isChecked ? getString(R.string.j_037) : getString(R.string.j_038))
                            + " · " + AppPrefs.getProxyHost(getActivity()) + ":" + AppPrefs.getProxyPort(getActivity()));
                }
            });
            btnProxy.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                UiDialog.showInputWithDesc(act, getString(R.string.j_039),
                        getString(R.string.j_040), getString(R.string.j_041), AppPrefs.getProxyHost(act), host -> {
                    AppPrefs.setProxyHost(act, host);
                    UiDialog.showInputWithDesc(act, getString(R.string.j_042),
                            getString(R.string.j_040), getString(R.string.j_043), String.valueOf(AppPrefs.getProxyPort(act)), portStr -> {
                        try { AppPrefs.setProxyPort(act, Integer.parseInt(portStr)); } catch (Exception ignored) {}
                        if (tvProxyDesc != null) {
                            tvProxyDesc.setText((AppPrefs.isProxyEnabled(act) ? getString(R.string.j_037) : getString(R.string.j_038))
                                    + " · " + AppPrefs.getProxyHost(act) + ":" + AppPrefs.getProxyPort(act));
                        }
                    });
                });
            });
        }

        // 字体大小
        if (btnFontSize != null && tvFontSize != null) {
            tvFontSize.setText(AppPrefs.getFontSize(getActivity()) == 0 ? getString(R.string.j_044)
                    : AppPrefs.getFontSize(getActivity()) == 2 ? getString(R.string.j_045) : getString(R.string.j_046));
            btnFontSize.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                String[] opts = {getString(R.string.j_044), getString(R.string.j_046), getString(R.string.j_045)};
                UiDialog.showPicker(act, getString(R.string.j_047), opts, AppPrefs.getFontSize(act), w -> {
                    AppPrefs.setFontSize(act, w);
                    act.recreate();
                });
            });
        }

        // 自定义背景
        if (btnCustomBg != null) {
            btnCustomBg.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                String[] opts = {getString(R.string.j_048), getString(R.string.j_049)};
                UiDialog.showPickerWithDesc(act, getString(R.string.j_050),
                        getString(R.string.j_051), opts, 0, w -> {
                    if (w == 0) {
                        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                        pick.setType("image/*");
                        try {
                            startActivityForResult(pick, 1001);
                        } catch (Exception ignored) {
                        }
                    } else {
                        AppPrefs.setBgPath(act, null);
                        act.recreate();
                    }
                });
            });
        }

        // 高级网络设置
        if (btnAdvancedNet != null) {
            btnAdvancedNet.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                String[] opts = {
                    getString(R.string.j_052),
                    getString(R.string.j_053) + (AppPrefs.isReqLog(act) ? getString(R.string.j_037) : getString(R.string.j_038)),
                    getString(R.string.j_054)
                };
                UiDialog.showPicker(act, getString(R.string.j_055), opts, 0, w -> {
                    switch (w) {
                        case 0:
                            UiDialog.showInput(act, "User-Agent", getString(R.string.j_056), AppPrefs.getUserAgent(act),
                                    ua -> AppPrefs.setUserAgent(act, ua));
                            break;
                        case 1:
                            AppPrefs.setReqLog(act, !AppPrefs.isReqLog(act));
                            break;
                        case 2:
                            String[] intervals = {getString(R.string.j_057), getString(R.string.j_058), getString(R.string.j_059), getString(R.string.j_060), getString(R.string.j_061), getString(R.string.j_062), getString(R.string.j_063)};
                            UiDialog.showPickerWithDesc(act, getString(R.string.j_064),
                                    getString(R.string.j_065), intervals, 0, i2 -> {
                                MainActivity ma = (MainActivity) getActivity();
                                if (i2 == 6) {
                                    // 自定义秒数
                                    UiDialog.showInput(act, getString(R.string.j_066), getString(R.string.j_067),
                                            String.valueOf(AppPrefs.getRefreshIntervalSec(act)), s -> {
                                        try {
                                            int sec = Integer.parseInt(s);
                                            if (sec >= 30) {
                                                AppPrefs.setRefreshIntervalSec(act, sec);
                                                AppPrefs.setAutoRefresh(act, true);
                                                if (ma != null) ma.scheduleAutoRefresh(true);
                                            }
                                        } catch (Exception ignored) {
                                        }
                                    });
                                } else {
                                    int sec = i2 == 1 ? 60 : i2 == 2 ? 300 : i2 == 3 ? 900 : i2 == 4 ? 1800 : i2 == 5 ? 3600 : 0;
                                    AppPrefs.setAutoRefresh(act, i2 > 0);
                                    if (i2 > 0) {
                                        AppPrefs.setRefreshIntervalSec(act, sec);
                                        if (ma != null) ma.scheduleAutoRefresh(true);
                                    }
                                }
                            });
                            break;
                    }
                });
            });
        }

        // Token 估算器
        if (btnTokenEst != null) {
            btnTokenEst.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                UiDialog.showInputWithDesc(act, getString(R.string.j_068),
                        getString(R.string.j_069), getString(R.string.j_070), "", input -> {
                    int tokens = TokenEstimator.estimate(input);
                    TokenUsageStore.add(act, tokens); // 记录用量（按天累计）
                    UiDialog.showConfirm(act, getString(R.string.j_071),
                            getString(R.string.j_072) + input.length() + getString(R.string.j_073) + tokens + getString(R.string.j_074)
                                    + "\n" + getString(R.string.usage_today) + TokenUsageStore.today(act),
                            getString(R.string.j_075), null, null, null);
                });
            });
        }

        // 清除数据
        if (btnClearData != null) {
            btnClearData.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                UiDialog.showConfirm(act, getString(R.string.j_076),
                        getString(R.string.j_077),
                        getString(R.string.j_078), getString(R.string.j_016),
                        () -> {
                            // 历史 + 多账户（含其加密 key）+ 全部加密数据（含 Keystore 密钥）
                            BalanceHistoryStore.clear(act);
                            AccountManager.clearAll(act);
                            CryptoManager.clearAll(act);
                            // 全部 prefs 文件
                            act.getSharedPreferences("ds_balance_prefs", 0).edit().clear().apply();
                            act.getSharedPreferences("ds_settings", 0).edit().clear().apply();
                            act.getSharedPreferences("ds_privacy", 0).edit().clear().apply();
                            act.getSharedPreferences("ds_theme", 0).edit().clear().apply();
                            act.getSharedPreferences("ds_crash_prefs", 0).edit().clear().apply();
                            act.getSharedPreferences("ds_debug_prefs", 0).edit().clear().apply();
                            act.getSharedPreferences("ds_accounts", 0).edit().clear().apply();
                            act.getSharedPreferences("ds_secure_prefs", 0).edit().clear().apply();
                            // 移除当前加密 key（CryptoManager.clearAll 已清整个 prefs，此步兜底）
                            CryptoManager.remove(act, act.getProviderKeyName(act.getCurrentProviderId()));
                            act.onChangeKey();
                        }, null);
            });
        }

        if (btnHistory != null) {
            btnHistory.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act != null) act.showHistoryFragment();
            });
        }

        if (btnUpdate != null) {
            btnUpdate.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act != null) UpdateChecker.check(act, true);
            });
        }

        if (btnDeps != null) {
            btnDeps.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act != null) act.showDependenciesFragment();
            });
        }

        btnAbout.setOnClickListener(v -> {
            MainActivity act = (MainActivity) getActivity();
            if (act != null) act.showAboutFragment();
        });

        btnChangeKey.setOnClickListener(v -> {
            MainActivity act = (MainActivity) getActivity();
            if (act != null) act.onChangeKey();
        });

        // 账户管理：选择账户后可切换 / 重命名 / 删除
        if (btnAccounts != null) {
            btnAccounts.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act == null) return;
                final int pid = act.getCurrentProviderId();
                final java.util.List<AccountManager.Account> accounts =
                        AccountManager.getAccounts(act, pid);
                if (accounts.isEmpty()) {
                    UiDialog.showConfirm(act, getString(R.string.j_079),
                            getString(R.string.j_080),
                            getString(R.string.j_075), null, null, null);
                    return;
                }
                String[] names = new String[accounts.size()];
                for (int i = 0; i < accounts.size(); i++) names[i] = accounts.get(i).name;
                UiDialog.showPicker(act, getString(R.string.j_081) + ProviderConfig.get(pid).name + "）",
                        names, -1, w -> {
                            final AccountManager.Account acc = accounts.get(w);
                            String[] ops = {getString(R.string.j_082), getString(R.string.j_083), getString(R.string.j_084)};
                            UiDialog.showPickerWithDesc(act, getString(R.string.j_085) + acc.name + getString(R.string.j_086),
                                    getString(R.string.j_087),
                                    ops, -1, op -> {
                                        if (op == 0) {
                                            act.onLoginSuccess(acc.key, pid, true);
                                        } else if (op == 1) {
                                            UiDialog.showInput(act, getString(R.string.j_088), getString(R.string.j_089), acc.name, newName -> {
                                                if (newName == null || newName.trim().isEmpty()) {
                                                    android.widget.Toast.makeText(act, getString(R.string.j_090),
                                                            android.widget.Toast.LENGTH_SHORT).show();
                                                    return;
                                                }
                                                AccountManager.removeAccount(act, pid, acc.name);
                                                if (AccountManager.saveAccount(act, pid, newName.trim(), acc.key)) {
                                                    android.widget.Toast.makeText(act, getString(R.string.j_091) + newName.trim(),
                                                            android.widget.Toast.LENGTH_SHORT).show();
                                                } else {
                                                    // 失败回滚，恢复原账户
                                                    AccountManager.saveAccount(act, pid, acc.name, acc.key);
                                                    android.widget.Toast.makeText(act, getString(R.string.j_092),
                                                            android.widget.Toast.LENGTH_SHORT).show();
                                                }
                                            });
                                        } else if (op == 2) {
                                            UiDialog.showConfirm(act, getString(R.string.j_093),
                                                    getString(R.string.j_094) + acc.name + getString(R.string.j_095),
                                                    getString(R.string.j_084), getString(R.string.j_016),
                                                    () -> {
                                                        AccountManager.removeAccount(act, pid, acc.name);
                                                        android.widget.Toast.makeText(act, getString(R.string.j_096) + acc.name,
                                                                android.widget.Toast.LENGTH_SHORT).show();
                                                    }, null);
                                        }
                                    });
                        });
            });
        }

        // 切换服务商：清掉当前 key，回登录页重新选择
        if (btnSwitchProvider != null) {
            btnSwitchProvider.setOnClickListener(v -> {
                MainActivity act = (MainActivity) getActivity();
                if (act != null) act.onChangeKey();
            });
        }

        btnDebug.setOnClickListener(v -> {
            MainActivity act = (MainActivity) getActivity();
            if (act != null) act.showDebugFragment();
        });

        // 入场动画：仅在首次进入时播放，避免每次打开设置重复弹跳
        if (savedInstanceState == null) {
            btnChangeKey.setAlpha(0f);
            btnChangeKey.setTranslationY(60f);
            btnChangeKey.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setDuration(400)
                    .setStartDelay(150)
                    .setInterpolator(new OvershootInterpolator(0.6f))
                    .start();

            if (btnSwitchProvider != null) {
                btnSwitchProvider.setAlpha(0f);
                btnSwitchProvider.setTranslationY(60f);
                btnSwitchProvider.animate()
                        .alpha(1f)
                        .translationY(0f)
                        .setDuration(400)
                        .setStartDelay(220)
                        .setInterpolator(new OvershootInterpolator(0.6f))
                        .start();
            }
        }


        // 内容入场动画：淡入 + 上滑
        view.setAlpha(0f);
        view.setTranslationY(24f);
        view.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(420)
                .setInterpolator(android.view.animation.AnimationUtils.loadInterpolator(getActivity(), android.R.interpolator.decelerate_cubic))
                .start();

        ThemeUtils.apply(view);
        // q9: 设置项图标统一跟随主题强调色
        applyIconAccent(view, ThemePrefs.getColor(getActivity()));
        return view;
    }

    /** 递归给设置项图标着色（跟随主题强调色）。 */
    private void applyIconAccent(View root, int accent) {
        if (root instanceof android.widget.ImageView) {
            ((android.widget.ImageView) root).setColorFilter(accent);
        }
        if (root instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) root;
            for (int i = 0; i < vg.getChildCount(); i++) {
                applyIconAccent(vg.getChildAt(i), accent);
            }
        }
    }

    /** 自定义背景选图结果：复制到应用私有目录后应用（B2 修复）。 */
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != 1001 || resultCode != android.app.Activity.RESULT_OK
                || data == null || data.getData() == null) {
            return;
        }
        MainActivity act = (MainActivity) getActivity();
        if (act == null) return;
        try {
            java.io.InputStream in = act.getContentResolver().openInputStream(data.getData());
            if (in == null) {
                android.widget.Toast.makeText(act, getString(R.string.j_097), android.widget.Toast.LENGTH_SHORT).show();
                return;
            }
            java.io.File outFile = new java.io.File(act.getFilesDir(), "custom_bg.png");
            java.io.FileOutputStream fos = new java.io.FileOutputStream(outFile);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) fos.write(buf, 0, n);
            fos.close();
            in.close();
            // 存私有文件 uri，App 重启后仍可读（GET_CONTENT 的临时授权可能失效）
            AppPrefs.setBgPath(act, android.net.Uri.fromFile(outFile).toString());
            // 即时应用背景，停留在当前页面（不再 recreate 返回主界面）
            act.applyCustomBg();
            android.widget.Toast.makeText(act, getString(R.string.j_098), android.widget.Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            android.widget.Toast.makeText(act, getString(R.string.j_097), android.widget.Toast.LENGTH_SHORT).show();
        }
    }
}