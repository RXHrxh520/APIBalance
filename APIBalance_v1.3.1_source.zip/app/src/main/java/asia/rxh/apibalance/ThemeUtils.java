package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 *
 * This file is part of APIBalance.
 *
 * APIBalance is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

/**
 * 主题应用工具：让「复古2000 / Code CLI」两套深色主题真正覆盖整个界面。
 * 递归调整视图树：浅色背景/卡片/输入框 → 主题深色，深色文字 → 主题浅色。
 * 默认主题（style=0）不调用任何改动。
 */
public final class ThemeUtils {

    private ThemeUtils() {
    }

    public static boolean isDarkTheme(Context c) {
        return ThemePrefs.getStyle(c) != ThemePrefs.STYLE_DEFAULT;
    }

    public static int cardColor(Context c) {
        return ThemePrefs.getStyle(c) == ThemePrefs.STYLE_CODE ? 0xFF10151C : 0xFF2A1B3D;
    }

    public static int inputColor(Context c) {
        return ThemePrefs.getStyle(c) == ThemePrefs.STYLE_CODE ? 0xFF1B242E : 0xFF3A2B55;
    }

    public static int textPrimary(Context c) {
        return ThemePrefs.getStyle(c) == ThemePrefs.STYLE_CODE ? 0xFFC9FFE0 : 0xFFFFE3F1;
    }

    public static int textSecondary(Context c) {
        return ThemePrefs.getStyle(c) == ThemePrefs.STYLE_CODE ? 0xFF66D9A0 : 0xFFC9A9C9;
    }

    /** CLI 终端强调色（荧光绿）。 */
    public static int cliAccent() {
        return 0xFF00E676;
    }

    /** 把主题应用到整个视图树。默认主题下仅处理图标强调色。 */
    public static void apply(View root) {
        if (root == null) return;
        Context c = root.getContext();
        boolean cli = ThemePrefs.getStyle(c) == ThemePrefs.STYLE_CODE;
        if (!isDarkTheme(c)) return;
        int bg = ThemePrefs.getBackground(c);
        int card = cardColor(c);
        int input = inputColor(c);
        int textP = textPrimary(c);
        int textS = textSecondary(c);
        float density = c.getResources().getDisplayMetrics().density;
        applyRecursive(root, bg, card, input, textP, textS, density, cli);
    }

    private static void applyRecursive(View v, int bg, int card, int input,
                                       int textP, int textS, float density, boolean cli) {
        // 背景一：纯色(ColorDrawable)浅色背景（顶栏/页底等）→ 主题深色
        if (v.getBackground() instanceof android.graphics.drawable.ColorDrawable) {
            try {
                int col = ((android.graphics.drawable.ColorDrawable) v.getBackground()).getColor();
                int rr = (col >> 16) & 0xFF, gg = (col >> 8) & 0xFF, bb = col & 0xFF;
                boolean lightBg = (rr + gg + bb) / 3 > 180;
                if (lightBg) {
                    v.setBackgroundColor(bg);
                }
            } catch (Exception ignored) {
            }
        }
        // 背景二：shape(solid)浅色背景（卡片/输入框）→ 主题深色
        if (v.getBackground() instanceof GradientDrawable) {
            try {
                GradientDrawable gd = (GradientDrawable) v.getBackground();
                android.content.res.ColorStateList csl = gd.getColor();
                if (csl != null) {
                    int col = csl.getDefaultColor();
                    int rr = (col >> 16) & 0xFF, gg = (col >> 8) & 0xFF, bb = col & 0xFF;
                    boolean lightBg = (rr + gg + bb) / 3 > 180;
                    if (lightBg) {
                        GradientDrawable nd = new GradientDrawable();
                        nd.setCornerRadius(20 * density);
                        nd.setColor(card);
                        if (cli) {
                            nd.setStroke((int) (1 * density + 0.5f), cliAccent());
                        }
                        v.setBackground(nd);
                    }
                } else if (cli) {
                    // 渐变 drawable（按钮/横幅）：CLI 下替换为荧光绿渐变
                    GradientDrawable nd = new GradientDrawable(
                            android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                            new int[]{0xFF00C853, 0xFF00E676});
                    nd.setCornerRadius(20 * density);
                    v.setBackground(nd);
                }
            } catch (Exception ignored) {
            }
        }
        // 文字：浅色文字 → 主题浅色；CLI 下用等宽字体（越像终端越好）
        if (v instanceof TextView) {
            TextView tv = (TextView) v;
            int cur = tv.getCurrentTextColor();
            int r = (cur >> 16) & 0xFF, g = (cur >> 8) & 0xFF, b = cur & 0xFF;
            int lum = (r + g + b) / 3;
            boolean darkText = lum < 120;
            boolean midText = lum >= 120 && lum <= 170;
            if (darkText) {
                tv.setTextColor(textP);
            } else if (midText) {
                tv.setTextColor(textS);
            }
            if (cli) {
                tv.setTypeface(android.graphics.Typeface.MONOSPACE);
            }
        }
        if (v instanceof EditText) {
            EditText et = (EditText) v;
            et.setTextColor(textP);
            et.setHintTextColor(0xFF7A8699);
            if (cli) {
                et.setTypeface(android.graphics.Typeface.MONOSPACE);
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++) {
                applyRecursive(vg.getChildAt(i), bg, card, input, textP, textS, density, cli);
            }
        }
    }
}
