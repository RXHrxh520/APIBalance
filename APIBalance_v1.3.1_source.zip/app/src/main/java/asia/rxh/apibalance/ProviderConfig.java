package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 *
 * This file is part of APIBalance.
 *
 * APIBalance is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * APIBalance is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * 多服务商余额查询配置。
 *
 * 当前支持三家：
 *  - DeepSeek  (默认, 官方余额 API)
 *  - Kimi      (Moonshot 开放平台)
 *  - 智谱 GLM   (BigModel 开放平台)
 *
 * 每家只暴露一个统一的 {@link BalanceResult}，UI 层无需感知各家字段差异。
 */
public final class ProviderConfig {

    public static final int PROVIDER_DEEPSEEK = 0;
    public static final int PROVIDER_KIMI = 1;
    public static final int PROVIDER_GLM = 2;
    public static final int PROVIDER_OPENAI = 3;
    public static final int PROVIDER_ANTHROPIC = 4;

    private static final Provider[] PROVIDERS = {
        new Provider(
            PROVIDER_DEEPSEEK,
            "DeepSeek",
            new String[]{"sk-"},
            "https://api.deepseek.com/user/balance"
        ),
        new Provider(
            PROVIDER_KIMI,
            "Kimi",
            new String[]{"sk-"},
            "https://api.moonshot.ai/v1/users/me/balance"
        ),
        new Provider(
            PROVIDER_GLM,
            "智谱GLM",
            new String[]{"sk-", "id."},
            "https://open.bigmodel.cn/api/paas/v4/balance"
        ),
        new Provider(
            PROVIDER_OPENAI,
            "OpenAI",
            new String[]{"sk-"},
            "https://api.openai.com/v1/dashboard/billing/credit_grants"
        ),
        new Provider(
            PROVIDER_ANTHROPIC,
            "Anthropic",
            new String[]{"sk-ant-"},
            "https://api.anthropic.com/v1/organizations/cost_report"
        )
    };

    private ProviderConfig() {
    }

    /** 按 id 取服务商；越界时回退 DeepSeek。 */
    public static Provider get(int providerId) {
        if (providerId < 0 || providerId >= PROVIDERS.length) {
            return PROVIDERS[PROVIDER_DEEPSEEK];
        }
        return PROVIDERS[providerId];
    }

    /** 服务商总数。 */
    public static int count() {
        return PROVIDERS.length;
    }

    /** 服务商显示名列表（用于选择器）。 */
    public static String[] names() {
        String[] n = new String[PROVIDERS.length];
        for (int i = 0; i < PROVIDERS.length; i++) n[i] = PROVIDERS[i].name;
        return n;
    }

    /** 判断某个服务商的 API Key 是否格式正确（可做弱校验）。 */
    public static boolean isValidKey(int providerId, String key) {
        if (key == null || key.trim().isEmpty()) return false;
        Provider p = get(providerId);
        if (p.keyPrefixes.length == 0) return true;
        for (String prefix : p.keyPrefixes) {
            if (key.startsWith(prefix)) return true;
        }
        return false;
    }

    /** 服务商配置 + 响应解析。 */
    public static final class Provider {
        public final int id;
        public final String name;
        public final String[] keyPrefixes;
        public final String balanceUrl;

        Provider(int id, String name, String[] keyPrefixes, String balanceUrl) {
            this.id = id;
            this.name = name;
            this.keyPrefixes = keyPrefixes;
            this.balanceUrl = balanceUrl;
        }

        /** 把该服务商的原始响应 JSON 解析为统一模型。解析失败抛异常由调用方兜底。 */
        public BalanceResult parse(String json) throws Exception {
            JSONObject root = new JSONObject(json);
            switch (id) {
                case PROVIDER_DEEPSEEK:
                    return parseDeepSeekLike(root, "CNY");
                case PROVIDER_GLM:
                    return parseDeepSeekLike(root, "CNY");
                case PROVIDER_KIMI:
                    return parseKimi(root);
                case PROVIDER_OPENAI:
                    return parseOpenAI(root);
                case PROVIDER_ANTHROPIC:
                    return parseAnthropic(root);
                default:
                    throw new IllegalStateException("unknown provider " + id);
            }
        }

        /** DeepSeek / 智谱：balance_infos[0]{currency,total_balance,granted_balance,topped_up_balance} */
        private BalanceResult parseDeepSeekLike(JSONObject root, String defaultCurrency) throws Exception {
            JSONArray infos = root.optJSONArray("balance_infos");
            if (infos == null || infos.length() == 0) {
                throw new IllegalStateException("响应中没有 balance_infos");
            }
            JSONObject info = infos.getJSONObject(0);
            String currency = info.optString("currency", defaultCurrency);
            double total = info.optDouble("total_balance", 0);
            double granted = info.optDouble("granted_balance", 0);
            double topped = info.optDouble("topped_up_balance", 0);
            return new BalanceResult(currency, total, granted, topped);
        }

        /**
         * OpenAI：/dashboard/billing/credit_grants
         * {total_granted, total_used, total_available, hard_limit_usd}，单位 USD。
         * 余额=可用额度；充值=已用额度。
         */
        private BalanceResult parseOpenAI(JSONObject root) throws Exception {
            double granted = root.optDouble("total_granted", 0);
            double used = root.optDouble("total_used", 0);
            double available = root.optDouble("total_available", 0);
            return new BalanceResult("USD", available, granted, used);
        }

        /**
         * Anthropic：/organizations/cost_report（组织用量报告）
         * Anthropic 无"余额"概念（后付费），此处展示本月用量。
         */
        private BalanceResult parseAnthropic(JSONObject root) throws Exception {
            double monthly = root.optDouble("monthly_cost", root.optDouble("total_cost", 0));
            return new BalanceResult("USD", monthly, 0, 0);
        }

        /** Kimi：data{available_balance,voucher_balance,cash_balance}，单位 USD。 */
        private BalanceResult parseKimi(JSONObject root) throws Exception {
            JSONObject data = root.optJSONObject("data");
            if (data == null) {
                throw new IllegalStateException("响应中没有 data");
            }
            double available = data.optDouble("available_balance", 0);
            double voucher = data.optDouble("voucher_balance", 0);
            double cash = data.optDouble("cash_balance", 0);
            // 总额=可用余额；赠金=代金券；充值=现金
            return new BalanceResult("USD", available, voucher, cash);
        }
    }

    /** 统一余额模型。 */
    public static final class BalanceResult {
        public final String currency;
        public final double totalBalance;
        public final double grantedBalance;
        public final double toppedUpBalance;

        BalanceResult(String currency, double total, double granted, double topped) {
            this.currency = currency;
            this.totalBalance = total;
            this.grantedBalance = granted;
            this.toppedUpBalance = topped;
        }
    }
}