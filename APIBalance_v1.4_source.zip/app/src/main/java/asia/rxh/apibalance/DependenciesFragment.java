package asia.rxh.apibalance;

/*
 * Copyright (C) 2026 软小寒
 *
 * This file is part of APIBalance.
 *
 * APIBalance is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * APIBalance is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * 第三方依赖统计页：如实列出本项目使用的所有技术栈/依赖/许可。
 */
public class DependenciesFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dependencies, container, false);

        ImageViewBtnBack(view);

        StringBuilder sb = new StringBuilder();
        sb.append(getString(R.string.f_001));
        sb.append("• v" + BuildConfig.VERSION_NAME + " (code " + BuildConfig.VERSION_CODE + ")\n\n");
        sb.append(getString(R.string.f_002));
        sb.append(getString(R.string.f_003));
        sb.append(getString(R.string.f_004));
        sb.append("• Android API 34（minSdk 26 / targetSdk 34 / compileSdk 34）\n");
        sb.append(getString(R.string.f_005));
        sb.append(getString(R.string.f_006));
        sb.append(getString(R.string.f_007));
        sb.append(getString(R.string.f_008));
        sb.append("  - MediaStore / ShortcutManager / AlarmManager / WindowManager\n");
        sb.append(getString(R.string.f_009));
        sb.append(getString(R.string.f_010));
        sb.append("• JDK 17 (Temurin)\n");
        sb.append("• Gradle 7.5\n");
        sb.append("• Android Gradle Plugin 7.4.2\n");
        sb.append(getString(R.string.f_011));
        sb.append("• buildTools 34.0.0\n\n");
        sb.append(getString(R.string.f_012));
        sb.append("• OkHttp 4.12.0（Apache 2.0）\n");
        sb.append("• Gson 2.10.1（Apache 2.0）\n");
        sb.append(getString(R.string.f_013));
        sb.append(getString(R.string.f_014));
        sb.append(getString(R.string.f_015));
        sb.append(getString(R.string.f_016));
        sb.append(getString(R.string.f_017));
        sb.append(getString(R.string.f_018));
        sb.append(getString(R.string.f_020));
        sb.append(getString(R.string.f_021));
        sb.append(getString(R.string.f_022));
        sb.append(getString(R.string.f_023));
        sb.append(getString(R.string.f_024));
        sb.append(getString(R.string.f_025));

        TextView tv = view.findViewById(R.id.tv_deps);
        tv.setText(sb.toString());

        ThemeUtils.apply(view);
        return view;
    }

    private void ImageViewBtnBack(final View view) {
        view.findViewById(R.id.btn_back).setOnClickListener(v -> {
            if (getActivity() != null && getFragmentManager().getBackStackEntryCount() > 0) {
                getFragmentManager().popBackStack();
            } else {
                MainActivity act = (MainActivity) getActivity();
                if (act != null) act.switchTab(0);
            }
        });
    }
}
