package com.rxh.ds;

/*
 * Copyright (C) 2026 软小寒
 * ... (AGPLv3, see MainActivity)
 */

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;

public class SettingsFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        ImageView btnBack = view.findViewById(R.id.btn_back);
        View btnChangeKey = view.findViewById(R.id.btn_change_key);
        View btnAbout = view.findViewById(R.id.btn_about);
        View btnDebug = view.findViewById(R.id.btn_debug);

        MainActivity activity = (MainActivity) getActivity();
        if (activity != null && activity.isDebugEnabled()) {
            btnDebug.setVisibility(View.VISIBLE);
        }

        btnBack.setOnClickListener(v -> {
            if (getActivity() != null) {
                getFragmentManager().popBackStack();
            }
        });

        btnAbout.setOnClickListener(v -> {
            MainActivity act = (MainActivity) getActivity();
            if (act != null) act.showAboutFragment();
        });

        btnChangeKey.setOnClickListener(v -> {
            MainActivity act = (MainActivity) getActivity();
            if (act != null) act.onChangeKey();
        });

        btnDebug.setOnClickListener(v -> {
            MainActivity act = (MainActivity) getActivity();
            if (act != null) act.showDebugFragment();
        });

        btnChangeKey.setAlpha(0f);
        btnChangeKey.setTranslationY(60f);
        btnChangeKey.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(400)
                .setStartDelay(150)
                .setInterpolator(new OvershootInterpolator(0.6f))
                .start();

        return view;
    }
}
