package com.rxh.ds;

/*
 * Copyright (C) 2026 软小寒
 * ... (AGPLv3, see MainActivity)
 */

import android.app.Fragment;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

public class BalanceFragment extends Fragment {

    private static final String ARG_API_KEY = "api_key";

    private String apiKey;

    private TextView tvCurrencySymbol, tvTotalBalance, tvCurrency;
    private TextView tvGrantedBalance, tvToppedUpBalance, tvRefreshLabel;
    private TextView tvBalanceError;
    private LinearLayout layoutLoading;
    private LinearLayout cardTotal, cardGranted, cardTopped, btnRefresh;
    private ImageView btnSettings, ivBalanceLogo;
    private Handler handler;
    private boolean isFirstLoad = true;
    private String lastCurrency = "";
    private double lastTotal = 0, lastGranted = 0, lastTopped = 0;

    public static BalanceFragment newInstance(String apiKey) {
        BalanceFragment frag = new BalanceFragment();
        Bundle args = new Bundle();
        args.putString(ARG_API_KEY, apiKey);
        frag.setArguments(args);
        return frag;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            apiKey = getArguments().getString(ARG_API_KEY);
        }
        handler = new Handler(Looper.getMainLooper());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_balance, container, false);

        tvCurrencySymbol = view.findViewById(R.id.tv_currency_symbol);
        tvTotalBalance = view.findViewById(R.id.tv_total_balance);
        tvCurrency = view.findViewById(R.id.tv_currency);
        tvGrantedBalance = view.findViewById(R.id.tv_granted_balance);
        tvToppedUpBalance = view.findViewById(R.id.tv_topped_up_balance);
        tvBalanceError = view.findViewById(R.id.tv_balance_error);
        layoutLoading = view.findViewById(R.id.layout_loading);
        cardTotal = view.findViewById(R.id.card_total);
        cardGranted = view.findViewById(R.id.card_granted);
        cardTopped = view.findViewById(R.id.card_topped);
        btnRefresh = view.findViewById(R.id.btn_refresh);
        tvRefreshLabel = view.findViewById(R.id.tv_refresh_label);
        btnSettings = view.findViewById(R.id.btn_settings);
        ivBalanceLogo = view.findViewById(R.id.iv_balance_logo);

        btnRefresh.setOnClickListener(v -> {
            if (tvRefreshLabel.getText().toString().equals("重载")) {
                tvRefreshLabel.setText("重载中…");
                btnRefresh.setAlpha(0.6f);
                fetchBalanceData();
            }
        });

        btnSettings.setOnClickListener(v -> {
            MainActivity activity = (MainActivity) getActivity();
            if (activity != null) {
                activity.showSettingsFragment();
            }
        });

        showLoading();
        fetchBalanceData();

        return view;
    }

    private void fetchBalanceData() {
        MainActivity activity = (MainActivity) getActivity();
        if (activity == null) return;

        activity.fetchBalance(apiKey, new MainActivity.OnBalanceFetchListener() {
            @Override
            public void onSuccess(String jsonResponse) {
                if (getActivity() == null) return;
                try {
                    JSONObject json = new JSONObject(jsonResponse);
                    JSONArray balanceInfos = json.getJSONArray("balance_infos");
                    if (balanceInfos.length() > 0) {
                        JSONObject info = balanceInfos.getJSONObject(0);
                        String currency = info.optString("currency", "CNY");
                        String totalBalance = info.optString("total_balance", "0.00");
                        String grantedBalance = info.optString("granted_balance", "0.00");
                        String toppedUpBalance = info.optString("topped_up_balance", "0.00");

                        if (isFirstLoad) {
                            updateUIFirst(currency, totalBalance, grantedBalance, toppedUpBalance);
                            isFirstLoad = false;
                        } else {
                            updateUIQuiet(currency, totalBalance, grantedBalance, toppedUpBalance);
                        }
                    }
                } catch (Exception e) {
                    if (isFirstLoad) showError("解析数据失败: " + e.getMessage());
                }
            }

            @Override
            public void onError(String errorMessage) {
                if (getActivity() == null) return;
                if (isFirstLoad) showError(errorMessage);
            }
        });
    }

    /** First load: full animations */
    private void updateUIFirst(String currency, String totalBalance, String grantedBalance, String toppedUpBalance) {
        hideLoading();
        lastCurrency = currency;
        try { lastTotal = Double.parseDouble(totalBalance); } catch (Exception e) { lastTotal = 0; }
        try { lastGranted = Double.parseDouble(grantedBalance); } catch (Exception e) { lastGranted = 0; }
        try { lastTopped = Double.parseDouble(toppedUpBalance); } catch (Exception e) { lastTopped = 0; }

        tvCurrency.setText(currency);
        String symbol = currency.equals("CNY") ? "¥" : "$";
        tvCurrencySymbol.setText(symbol);

        // Animate logo entrance
        ivBalanceLogo.setAlpha(0f);
        ivBalanceLogo.setScaleX(0f);
        ivBalanceLogo.setScaleY(0f);
        ivBalanceLogo.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(500)
                .setInterpolator(new OvershootInterpolator(1.0f))
                .start();

        // Animate cards entrance
        MainActivity activity = (MainActivity) getActivity();
        if (activity != null) {
            activity.animateCardEntrance(cardTotal, 100);
            activity.animateCardEntrance(cardGranted, 250);
            activity.animateCardEntrance(cardTopped, 350);
            activity.animateNumberCount(tvTotalBalance, 0, lastTotal, "", "");
        }
        tvGrantedBalance.setText(formatBalance(grantedBalance));
        tvToppedUpBalance.setText(formatBalance(toppedUpBalance));
    }

    /** Subsequent refresh: silent update, animate only changed numbers */
    private void updateUIQuiet(String currency, String totalBalance, String grantedBalance, String toppedUpBalance) {
        hideLoading();
        tvCurrency.setText(currency);
        String symbol = currency.equals("CNY") ? "¥" : "$";
        tvCurrencySymbol.setText(symbol);

        try {
            double newTotal = Double.parseDouble(totalBalance);
            double newGranted = Double.parseDouble(grantedBalance);
            double newTopped = Double.parseDouble(toppedUpBalance);

            if (Math.abs(newTotal - lastTotal) > 0.001) {
                MainActivity activity = (MainActivity) getActivity();
                if (activity != null) activity.animateNumberCount(tvTotalBalance, lastTotal, newTotal, "", "");
                lastTotal = newTotal;
            }
            if (Math.abs(newGranted - lastGranted) > 0.001) {
                tvGrantedBalance.setText(formatBalance(grantedBalance));
                lastGranted = newGranted;
            } else {
                tvGrantedBalance.setText(formatBalance(grantedBalance));
            }
            if (Math.abs(newTopped - lastTopped) > 0.001) {
                tvToppedUpBalance.setText(formatBalance(toppedUpBalance));
                lastTopped = newTopped;
            } else {
                tvToppedUpBalance.setText(formatBalance(toppedUpBalance));
            }
        } catch (NumberFormatException e) {
            tvTotalBalance.setText(formatBalance(totalBalance));
            tvGrantedBalance.setText(formatBalance(grantedBalance));
            tvToppedUpBalance.setText(formatBalance(toppedUpBalance));
        }
        hideError();
    }

    private void hideError() {
        if (tvBalanceError.getVisibility() == View.VISIBLE) {
            tvBalanceError.animate().alpha(0f).setDuration(200)
                    .withEndAction(() -> tvBalanceError.setVisibility(View.GONE)).start();
        }
    }

    private String formatBalance(String raw) {
        if (raw == null || raw.isEmpty()) return "0.00";
        try {
            double d = Double.parseDouble(raw);
            return String.format("%.2f", d);
        } catch (NumberFormatException e) {
            return raw;
        }
    }

    private void showLoading() {
        layoutLoading.setVisibility(View.VISIBLE);
        tvBalanceError.setVisibility(View.GONE);
        cardTotal.setAlpha(0f);
        cardGranted.setAlpha(0f);
        cardTopped.setAlpha(0f);
    }

    private void hideLoading() {
        layoutLoading.setVisibility(View.GONE);
        cardTotal.setVisibility(View.VISIBLE);
        cardTotal.setAlpha(1f);
        cardTotal.setTranslationY(0f);
        cardTotal.setScaleX(1f);
        cardTotal.setScaleY(1f);
        cardGranted.setVisibility(View.VISIBLE);
        cardGranted.setAlpha(1f);
        cardGranted.setTranslationY(0f);
        cardGranted.setScaleX(1f);
        cardGranted.setScaleY(1f);
        cardTopped.setVisibility(View.VISIBLE);
        cardTopped.setAlpha(1f);
        cardTopped.setTranslationY(0f);
        cardTopped.setScaleX(1f);
        cardTopped.setScaleY(1f);
        tvRefreshLabel.setText("重载");
        btnRefresh.setAlpha(1f);
    }

    private void showError(String msg) {
        hideLoading();
        tvBalanceError.setText(msg);
        tvBalanceError.setVisibility(View.VISIBLE);
        tvBalanceError.setAlpha(0f);
        tvBalanceError.animate().alpha(1f).setDuration(300).start();
    }
}
