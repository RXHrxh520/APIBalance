package com.rxh.ds;

/*
 * Copyright (C) 2026 软小寒
 * ... (AGPLv3, see MainActivity)
 */

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Random;

public class LoginFragment extends Fragment {

    private EditText etApiKey, etCaptcha;
    private Switch swAutoLogin;
    private TextView btnQuery;
    private TextView tvError;
    private ImageView ivLogo;
    private LinearLayout cardCaptcha;
    private TextView tvCaptchaQuestion;
    private View cardLogin;
    private boolean isQuerying = false;
    private int captchaAnswer;
    private Random random = new Random();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        etApiKey = view.findViewById(R.id.et_api_key);
        etCaptcha = view.findViewById(R.id.et_captcha);
        swAutoLogin = view.findViewById(R.id.sw_auto_login);
        btnQuery = view.findViewById(R.id.btn_query);
        tvError = view.findViewById(R.id.tv_error);
        ivLogo = view.findViewById(R.id.iv_logo);
        cardLogin = view.findViewById(R.id.card_login);
        cardCaptcha = view.findViewById(R.id.card_captcha);
        tvCaptchaQuestion = view.findViewById(R.id.tv_captcha_question);

        swAutoLogin.setChecked(true);

        // Entrance animations
        ivLogo.setAlpha(0f);
        ivLogo.setScaleX(0.5f);
        ivLogo.setScaleY(0.5f);
        ivLogo.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(600)
                .setStartDelay(100)
                .setInterpolator(new OvershootInterpolator(1.2f))
                .start();

        cardLogin.setAlpha(0f);
        cardLogin.setTranslationY(100f);
        cardLogin.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(500)
                .setStartDelay(300)
                .setInterpolator(new OvershootInterpolator(0.8f))
                .start();

        btnQuery.setOnClickListener(v -> {
            if (isQuerying) return;
            String apiKey = etApiKey.getText().toString().trim();
            if (apiKey.isEmpty()) {
                showError("请输入 API 密钥");
                return;
            }
            if (!apiKey.startsWith("sk-")) {
                showError("API 密钥格式不正确，应以 sk- 开头");
                return;
            }
            // If captcha not shown yet → show it first
            if (cardCaptcha.getVisibility() != View.VISIBLE) {
                showCaptcha();
                return;
            }
            // Verify captcha
            String answerStr = etCaptcha.getText().toString().trim();
            if (answerStr.isEmpty()) {
                showError("请回答人机验证问题");
                return;
            }
            try {
                int answer = Integer.parseInt(answerStr);
                if (answer != captchaAnswer) {
                    // Wrong answer → new question
                    showError("答案错误，请重试");
                    setRandomCaptcha();
                    etCaptcha.setText("");
                    return;
                }
            } catch (NumberFormatException e) {
                showError("请输入数字");
                return;
            }
            doQuery(apiKey);
        });

        return view;
    }

    private void showCaptcha() {
        setRandomCaptcha();
        cardCaptcha.setVisibility(View.VISIBLE);
        cardCaptcha.setAlpha(0f);
        cardCaptcha.setTranslationY(30f);
        cardCaptcha.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(350)
                .setInterpolator(new OvershootInterpolator(0.6f))
                .start();
    }

    private void setRandomCaptcha() {
        int a = random.nextInt(11); // 0-10
        int b = random.nextInt(11); // 0-10
        captchaAnswer = a + b;
        tvCaptchaQuestion.setText(a + " + " + b + " = ?");
    }

    private void doQuery(String apiKey) {
        isQuerying = true;
        hideError();
        btnQuery.setText("正在查询...");
        btnQuery.setAlpha(0.7f);
        btnQuery.setClickable(false);

        MainActivity activity = (MainActivity) getActivity();
        if (activity == null) return;

        activity.fetchBalance(apiKey, new MainActivity.OnBalanceFetchListener() {
            @Override
            public void onSuccess(String jsonResponse) {
                if (getActivity() == null) return;
                boolean autoLogin = swAutoLogin.isChecked();
                activity.onLoginSuccess(apiKey, autoLogin);
            }

            @Override
            public void onError(String errorMessage) {
                if (getActivity() == null) return;
                isQuerying = false;
                btnQuery.setText("查询余额");
                btnQuery.setAlpha(1f);
                btnQuery.setClickable(true);
                showError(errorMessage);
                // Shake error
                tvError.setTranslationX(0f);
                tvError.animate()
                        .translationX(10f).setDuration(50)
                        .withEndAction(() -> tvError.animate()
                                .translationX(-10f).setDuration(50)
                                .withEndAction(() -> tvError.animate()
                                        .translationX(5f).setDuration(50)
                                        .withEndAction(() -> tvError.animate()
                                                .translationX(0f).setDuration(50).start())))
                        .start();
            }
        });
    }

    private void showError(String msg) {
        tvError.setText(msg);
        tvError.setVisibility(View.VISIBLE);
        tvError.setAlpha(0f);
        tvError.animate().alpha(1f).setDuration(200).start();
    }

    private void hideError() {
        tvError.animate().alpha(0f).setDuration(150)
                .withEndAction(() -> tvError.setVisibility(View.GONE)).start();
    }
}
