package com.rxh.ds;

/*
 * Copyright (C) 2026 软小寒
 * ... (AGPLv3, see MainActivity)
 */

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CrashActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 使用代码构建界面，避免资源加载二次崩溃
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(0xFFF6F3FA);

        android.widget.LinearLayout root = new android.widget.LinearLayout(this);
        root.setOrientation(android.widget.LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(48), dp(24), dp(24));
        root.setGravity(android.view.Gravity.CENTER_HORIZONTAL);

        // 红色警告图标（代码画圆）
        android.widget.LinearLayout iconCircle = new android.widget.LinearLayout(this);
        iconCircle.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dp(72), dp(72)));
        android.graphics.drawable.GradientDrawable circle = new android.graphics.drawable.GradientDrawable();
        circle.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        circle.setColor(0xFFB3261E);
        iconCircle.setBackground(circle);
        iconCircle.setGravity(android.view.Gravity.CENTER);

        TextView iconText = new TextView(this);
        iconText.setText("!");
        iconText.setTextColor(0xFFFFFFFF);
        iconText.setTextSize(36);
        iconText.setTypeface(null, android.graphics.Typeface.BOLD);
        iconCircle.addView(iconText);
        root.addView(iconCircle);

        // 标题
        addSpace(root, dp(20));
        TextView title = new TextView(this);
        title.setText("应用发生异常");
        title.setTextColor(0xFF1C1B1F);
        title.setTextSize(22);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setGravity(android.view.Gravity.CENTER);
        root.addView(title);

        addSpace(root, dp(8));
        TextView subtitle = new TextView(this);
        subtitle.setText("请长按下方内容复制，反馈给开发者");
        subtitle.setTextColor(0xFF49454F);
        subtitle.setTextSize(14);
        subtitle.setGravity(android.view.Gravity.CENTER);
        root.addView(subtitle);

        // 错误卡片
        addSpace(root, dp(24));
        android.widget.LinearLayout errorCard = new android.widget.LinearLayout(this);
        errorCard.setOrientation(android.widget.LinearLayout.VERTICAL);
        errorCard.setPadding(dp(20), dp(20), dp(20), dp(20));
        errorCard.setBackgroundColor(0xFFFFFFFF);
        android.graphics.drawable.GradientDrawable cardBg = new android.graphics.drawable.GradientDrawable();
        cardBg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        cardBg.setCornerRadius(dp(16));
        cardBg.setColor(0xFFFFFFFF);
        cardBg.setStroke(dp(1), 0xFFE5E7EB);
        errorCard.setBackground(cardBg);
        errorCard.setLayoutParams(new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));

        // 错误信息
        TextView labelMsg = new TextView(this);
        labelMsg.setText("错误信息");
        labelMsg.setTextColor(0xFF6750A4);
        labelMsg.setTextSize(12);
        labelMsg.setTypeface(null, android.graphics.Typeface.BOLD);
        errorCard.addView(labelMsg);

        addSpace(errorCard, dp(6));

        String crashMsg = getIntent().getStringExtra("crash_message");
        String crashTrace = getIntent().getStringExtra("crash_trace");

        if (crashMsg == null) {
            String[] info = CrashHandler.getCrashInfo(this);
            crashMsg = info[0];
            crashTrace = info[1];
        }

        TextView tvErrorMsg = new TextView(this);
        tvErrorMsg.setText(crashMsg != null ? crashMsg : "未知错误");
        tvErrorMsg.setTextColor(0xFFB3261E);
        tvErrorMsg.setTextSize(15);
        tvErrorMsg.setTypeface(null, android.graphics.Typeface.BOLD);
        tvErrorMsg.setPadding(dp(12), dp(10), dp(12), dp(10));
        android.graphics.drawable.GradientDrawable errBg = new android.graphics.drawable.GradientDrawable();
        errBg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        errBg.setCornerRadius(dp(8));
        errBg.setColor(0xFFF9DEDC);
        tvErrorMsg.setBackground(errBg);
        tvErrorMsg.setTextIsSelectable(true);
        errorCard.addView(tvErrorMsg);

        addSpace(errorCard, dp(16));

        // 堆栈追踪
        TextView labelStack = new TextView(this);
        labelStack.setText("堆栈追踪");
        labelStack.setTextColor(0xFF6750A4);
        labelStack.setTextSize(12);
        labelStack.setTypeface(null, android.graphics.Typeface.BOLD);
        errorCard.addView(labelStack);

        addSpace(errorCard, dp(6));

        TextView tvStackTrace = new TextView(this);
        tvStackTrace.setText(crashTrace != null ? crashTrace : "无堆栈信息");
        tvStackTrace.setTextColor(0xFF49454F);
        tvStackTrace.setTextSize(11);
        tvStackTrace.setTypeface(android.graphics.Typeface.MONOSPACE);
        tvStackTrace.setLineSpacing(dp(2), 1f);
        tvStackTrace.setPadding(dp(12), dp(10), dp(12), dp(10));
        tvStackTrace.setMaxHeight(dp(300));
        tvStackTrace.setMovementMethod(new ScrollingMovementMethod());
        android.graphics.drawable.GradientDrawable stackBg = new android.graphics.drawable.GradientDrawable();
        stackBg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        stackBg.setCornerRadius(dp(8));
        stackBg.setColor(0xFFF5F5F5);
        tvStackTrace.setBackground(stackBg);
        tvStackTrace.setTextIsSelectable(true);
        errorCard.addView(tvStackTrace);

        root.addView(errorCard);

        // 重启按钮
        addSpace(root, dp(28));
        TextView btnRestart = new TextView(this);
        btnRestart.setText("重启应用");
        btnRestart.setTextColor(0xFFFFFFFF);
        btnRestart.setTextSize(16);
        btnRestart.setTypeface(null, android.graphics.Typeface.BOLD);
        btnRestart.setGravity(android.view.Gravity.CENTER);
        btnRestart.setPadding(dp(16), dp(14), dp(16), dp(14));
        btnRestart.setMinHeight(dp(50));
        android.graphics.drawable.GradientDrawable btnBg = new android.graphics.drawable.GradientDrawable();
        btnBg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        btnBg.setCornerRadius(dp(16));
        btnBg.setColors(new int[]{0xFF6750A4, 0xFF4F378B});
        btnBg.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.TL_BR);
        btnRestart.setBackground(btnBg);
        btnRestart.setOnClickListener(v -> {
            CrashHandler.clearCrash(CrashActivity.this);
            Intent intent = new Intent(CrashActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
        root.addView(btnRestart);

        // 版本信息
        addSpace(root, dp(16));
        TextView tvVersion = new TextView(this);
        tvVersion.setText("v1.0 (BETA) · 开发人员：软小寒 · 交流群：194337615");
        tvVersion.setTextColor(0xFF79747E);
        tvVersion.setTextSize(11);
        tvVersion.setGravity(android.view.Gravity.CENTER);
        root.addView(tvVersion);

        scrollView.addView(root);
        setContentView(scrollView);

        // 入场动画
        iconCircle.setAlpha(0f);
        iconCircle.setScaleX(0.5f);
        iconCircle.setScaleY(0.5f);
        iconCircle.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(500).setStartDelay(100)
                .setInterpolator(new OvershootInterpolator(0.8f)).start();

        errorCard.setAlpha(0f);
        errorCard.setTranslationY(60f);
        errorCard.animate().alpha(1f).translationY(0f)
                .setDuration(450).setStartDelay(250)
                .setInterpolator(new OvershootInterpolator(0.5f)).start();
    }

    private void addSpace(android.widget.LinearLayout parent, int dp) {
        android.view.View space = new android.view.View(this);
        space.setLayoutParams(new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, dp));
        parent.addView(space);
    }

    private int dp(int px) {
        return (int) (px * getResources().getDisplayMetrics().density + 0.5f);
    }
}
