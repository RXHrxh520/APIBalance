package com.rxh.ds;

/*
 * Copyright (C) 2026 软小寒
 *
 * This file is part of DS余额查询.
 *
 * DS余额查询 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DS余额查询 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.TextView;

public class MainActivity extends Activity {

    private static final String PREFS_NAME = "ds_balance_prefs";
    private static final String KEY_API_KEY = "api_key";
    private static final String KEY_AUTO_LOGIN = "auto_login";
    private static final String BALANCE_API_URL = "https://api.deepseek.com/user/balance";
    private static final String PREFS_DEBUG = "ds_debug_prefs";
    private static final String KEY_DEBUG = "debug_enabled";

    private String currentApiKey;
    private Handler mainHandler;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Follow system night mode
        int night = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        setTheme(night == Configuration.UI_MODE_NIGHT_YES
                ? R.style.HerGeneratedTheme_Dark
                : R.style.HerGeneratedTheme_FollowSystem);

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        mainHandler = new Handler(Looper.getMainLooper());

        // Install crash handler
        CrashHandler.install(getApplicationContext());

        // Check for pending crash
        if (CrashHandler.hasPendingCrash(getApplicationContext())) {
            String[] crashInfo = CrashHandler.getCrashInfo(getApplicationContext());
            Intent crashIntent = new Intent(this, CrashActivity.class);
            crashIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            crashIntent.putExtra("crash_message", crashInfo[0]);
            crashIntent.putExtra("crash_trace", crashInfo[1]);
            startActivity(crashIntent);
            finish();
            return;
        }

        // Immersive status bar
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            window.setStatusBarColor(android.graphics.Color.TRANSPARENT);
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        } else {
            window.setStatusBarColor(0x00000000);
        }
        mainHandler = new Handler(Looper.getMainLooper());

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Startup open-source notice (show once)
        if (!prefs.getBoolean("oss_notice_shown", false)) {
            prefs.edit().putBoolean("oss_notice_shown", true).apply();
            new AlertDialog.Builder(this)
                .setTitle("开源声明")
                .setMessage("本软件永远开源免费！\n\n如果您是付费购买的，请立即联系对应方退款。如拒不退款，请联系项目原作者协助（无法保证百分百）。\n\n该项目基于AGPLv3协议开源\n项目地址:\nhttps://github.com/RXHrxh520/DeepseekBalance\n\n感谢您的支持！")
                .setPositiveButton("我知道了", null)
                .setCancelable(false)
                .show();
        }

        boolean autoLogin = prefs.getBoolean(KEY_AUTO_LOGIN, false);
        String savedKey = prefs.getString(KEY_API_KEY, "");

        if (autoLogin && !savedKey.isEmpty()) {
            currentApiKey = savedKey;
            showBalanceFragment(savedKey, false);
        } else {
            showLoginFragment(false);
        }
    }

    public void showLoginFragment(boolean animate) {
        LoginFragment frag = new LoginFragment();
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        if (animate) {
            ft.setCustomAnimations(R.animator.slide_in_left, R.animator.slide_out_right);
        }
        ft.replace(R.id.container, frag).commit();
    }

    public void showBalanceFragment(String apiKey, boolean animate) {
        currentApiKey = apiKey;
        BalanceFragment frag = BalanceFragment.newInstance(apiKey);
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        if (animate) {
            ft.setCustomAnimations(R.animator.slide_in_right, R.animator.slide_out_left);
        }
        ft.replace(R.id.container, frag).commit();
    }

    public void showSettingsFragment() {
        SettingsFragment frag = new SettingsFragment();
        getFragmentManager()
                .beginTransaction()
                .setCustomAnimations(R.animator.slide_in_right, R.animator.slide_out_left)
                .replace(R.id.container, frag)
                .addToBackStack(null)
                .commit();
    }

    public void showAboutFragment() {
        AboutFragment frag = new AboutFragment();
        getFragmentManager()
                .beginTransaction()
                .setCustomAnimations(R.animator.slide_in_right, R.animator.slide_out_left)
                .replace(R.id.container, frag)
                .addToBackStack(null)
                .commit();
    }

    public void showDebugFragment() {
        DebugFragment frag = new DebugFragment();
        getFragmentManager()
                .beginTransaction()
                .setCustomAnimations(R.animator.slide_in_right, R.animator.slide_out_left)
                .replace(R.id.container, frag)
                .addToBackStack(null)
                .commit();
    }

    public boolean isDebugEnabled() {
        return getSharedPreferences(PREFS_DEBUG, MODE_PRIVATE).getBoolean(KEY_DEBUG, false);
    }

    public void onLoginSuccess(String apiKey, boolean autoLogin) {
        currentApiKey = apiKey;
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(KEY_AUTO_LOGIN, autoLogin);
        if (autoLogin) {
            editor.putString(KEY_API_KEY, apiKey);
        } else {
            editor.remove(KEY_API_KEY);
        }
        editor.apply();
        showBalanceFragment(apiKey, true);
    }

    public void onChangeKey() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().remove(KEY_API_KEY).apply();
        currentApiKey = null;
        showLoginFragment(true);
    }

    public String getCurrentApiKey() {
        return currentApiKey;
    }

    public void animateCardEntrance(View view, int delay) {
        view.setAlpha(0f);
        view.setTranslationY(80f);
        view.setScaleX(0.9f);
        view.setScaleY(0.9f);
        view.animate()
                .alpha(1f)
                .translationY(0f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(500)
                .setStartDelay(delay)
                .setInterpolator(new OvershootInterpolator(0.8f))
                .start();
    }

    public void animateNumberCount(TextView tv, double from, double to, String prefix, String suffix) {
        ValueAnimator anim = ValueAnimator.ofFloat((float) from, (float) to);
        anim.setDuration(1000);
        anim.setInterpolator(new DecelerateInterpolator());
        anim.addUpdateListener(animation -> {
            float val = (float) animation.getAnimatedValue();
            tv.setText(String.format("%s%.2f%s", prefix, val, suffix));
        });
        anim.start();
    }

    public void fetchBalance(String apiKey, OnBalanceFetchListener listener) {
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(BALANCE_API_URL);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Authorization", "Bearer " + apiKey);
                conn.setRequestProperty("Accept", "application/json");
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(15000);

                int responseCode = conn.getResponseCode();

                if (responseCode == 200) {
                    BufferedReader reader = new BufferedReader(
                            new InputStreamReader(conn.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                    }
                    reader.close();
                    String json = sb.toString();
                    mainHandler.post(() -> listener.onSuccess(json));
                } else if (responseCode == 401) {
                    mainHandler.post(() -> listener.onError("API 密钥无效，请检查后重试"));
                } else if (responseCode == 429) {
                    mainHandler.post(() -> listener.onError("请求过于频繁，请稍后重试"));
                } else {
                    BufferedReader errorReader = new BufferedReader(
                            new InputStreamReader(conn.getErrorStream(), "UTF-8"));
                    StringBuilder errSb = new StringBuilder();
                    String errLine;
                    while ((errLine = errorReader.readLine()) != null) {
                        errSb.append(errLine);
                    }
                    errorReader.close();
                    mainHandler.post(() -> listener.onError("请求失败 (" + responseCode + "): " + errSb.toString()));
                }
            } catch (java.net.SocketTimeoutException e) {
                mainHandler.post(() -> listener.onError("网络连接超时，请检查网络后重试"));
            } catch (java.net.UnknownHostException e) {
                mainHandler.post(() -> listener.onError("无法连接到服务器，请检查网络"));
            } catch (Exception e) {
                mainHandler.post(() -> listener.onError("网络错误: " + e.getMessage()));
            } finally {
                if (conn != null) conn.disconnect();
            }
        }).start();
    }

    public interface OnBalanceFetchListener {
        void onSuccess(String jsonResponse);
        void onError(String errorMessage);
    }
}
