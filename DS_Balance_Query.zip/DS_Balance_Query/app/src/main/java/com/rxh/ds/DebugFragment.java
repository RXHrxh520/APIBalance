package com.rxh.ds;

/*
 * Copyright (C) 2026 软小寒
 * ... (AGPLv3, see MainActivity)
 */

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class DebugFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_debug, container, false);

        TextView btnCrash = view.findViewById(R.id.btn_crash_test);
        btnCrash.setOnClickListener(v -> {
            throw new RuntimeException("崩溃测试 — 这是手动触发的测试异常");
        });

        return view;
    }
}
