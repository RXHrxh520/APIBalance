# DS余额查询

一个极简的 DeepSeek API 余额查询安卓工具。

## 功能
- 输入API Key查询赠金、总余额、充值余额
- 密钥仅保存在本地，不上传任何服务器
- 无广告、无多余SDK

## 如何使用
1. 输入你的 DeepSeek API Key
2. 完成算术验证
3. 查看余额

## 开源协议
本项目基于 GNU Affero General Public License v3.0 开源。